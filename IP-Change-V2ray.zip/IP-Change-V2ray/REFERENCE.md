# IP-Change-V2ray Reference

## Command

```text
/IP-Change-V2ray
```

## Sources

```text
https://github.com/barry-far/v2ray-config
https://github.com/ebrasha/free-v2ray-public-list
```

Fresh shallow clone both sources on every run.

## Supported URI schemes

```text
vmess vless trojan ss ssr tuic hysteria2 hy2
```

## Ranking defaults

```text
Latency   35%
Bandwidth 40%
Stability 15%
Jitter    10%
```

## Benchmark rule

Do not rank by ICMP ping alone. A strong candidate must pass a real proxy HTTPS request, show stable latency, survive repeated requests, and deliver real bounded download throughput.

## Security rule

Treat cloned repositories as untrusted configuration data. Do not execute repository code.
