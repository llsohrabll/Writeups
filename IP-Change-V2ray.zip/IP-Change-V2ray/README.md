# IP-Change-V2ray

Claude Code skill invoked with:

```text
/IP-Change-V2ray
```

Each invocation fresh-clones the two configured public repositories, extracts supported proxy configs, deduplicates them, resolves fresh IPs, tests real proxy connectivity, measures latency/stability, bandwidth-tests finalists, prints a bold-red Top 10, and asks you to choose one.

## Install per project

```text
.claude/skills/IP-Change-V2ray/
```

## Install globally

```text
~/.claude/skills/IP-Change-V2ray/
```

The repositories are treated as data only; cloned scripts are never executed.
