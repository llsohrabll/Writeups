#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))

def inv_norm(value, lo, hi):
    if value is None: return 0.0
    if hi <= lo: return 1.0
    return clamp(1.0 - ((value - lo) / (hi - lo)))

def pos_norm(value, lo, hi):
    if value is None: return 0.0
    if hi <= lo: return 1.0
    return clamp((value - lo) / (hi - lo))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--latency-weight", type=float, default=35)
    ap.add_argument("--bandwidth-weight", type=float, default=40)
    ap.add_argument("--stability-weight", type=float, default=15)
    ap.add_argument("--jitter-weight", type=float, default=10)
    ap.add_argument("--min-success-rate", type=float, default=0.60)
    args = ap.parse_args()

    rows = []
    with open(args.input, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip(): continue
            r = json.loads(line)
            if not r.get("proxy_connect_ok"): continue
            if float(r.get("success_rate", 0)) < args.min_success_rate: continue
            if r.get("median_latency_ms") is None or r.get("jitter_ms") is None or r.get("median_bandwidth_mbps") is None: continue
            rows.append(r)

    if not rows:
        Path(args.output).write_text("[]\n", encoding="utf-8")
        print("No fully benchmarked candidates qualified.")
        return

    lats = [float(r["median_latency_ms"]) for r in rows]
    jits = [float(r["jitter_ms"]) for r in rows]
    bws = [float(r["median_bandwidth_mbps"]) for r in rows]
    stabs = [float(r.get("success_rate", 0)) for r in rows]
    lat_lo, lat_hi = min(lats), max(lats)
    jit_lo, jit_hi = min(jits), max(jits)
    bw_lo, bw_hi = min(bws), max(bws)
    st_lo, st_hi = min(stabs), max(stabs)
    total_w = args.latency_weight + args.bandwidth_weight + args.stability_weight + args.jitter_weight

    for r in rows:
        score = (
            inv_norm(float(r["median_latency_ms"]), lat_lo, lat_hi) * args.latency_weight +
            pos_norm(float(r["median_bandwidth_mbps"]), bw_lo, bw_hi) * args.bandwidth_weight +
            pos_norm(float(r.get("success_rate", 0)), st_lo, st_hi) * args.stability_weight +
            inv_norm(float(r["jitter_ms"]), jit_lo, jit_hi) * args.jitter_weight
        ) / total_w * 100.0
        r["score"] = round(score, 2)

    rows.sort(key=lambda r: (-float(r.get("score", 0)), float(r["median_latency_ms"]), -float(r["median_bandwidth_mbps"])))
    top = rows[:args.top]
    for i, r in enumerate(top, 1): r["rank"] = i
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(top, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote Top {len(top)} to {args.output}")

if __name__ == "__main__":
    main()
