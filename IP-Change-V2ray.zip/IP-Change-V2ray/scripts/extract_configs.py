#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

SCHEMES = ("vmess", "vless", "trojan", "ss", "ssr", "tuic", "hysteria2", "hy2")
URI_RE = re.compile(r'(?i)\\b(?:' + "|".join(map(re.escape, SCHEMES)) + r')://[^\\s<>"\\\'`]+')
TEXT_SUFFIXES = {".txt", ".md", ".json", ".yaml", ".yml", ".conf", ".cfg", ".ini", ".csv", ".tsv", ".list", ".sub", ".log", ".html", ".js"}

def clean_uri(uri: str) -> str:
    return uri.strip().rstrip("),.;]}>")

def protocol_of(uri: str) -> str:
    return uri.split("://", 1)[0].lower()

def stable_fingerprint(uri: str) -> str:
    try:
        scheme, rest = uri.split("://", 1)
        rest = rest.split("#", 1)[0].strip()
        material = f"{scheme.lower()}://{rest}"
    except ValueError:
        material = uri.strip()
    return hashlib.sha256(material.encode("utf-8", "ignore")).hexdigest()

def iter_text_files(root: Path):
    for p in root.rglob("*"):
        if not p.is_file() or ".git" in p.parts:
            continue
        try:
            size = p.stat().st_size
        except OSError:
            continue
        if p.suffix.lower() in TEXT_SUFFIXES or size < 5_000_000:
            yield p

def extract(root: Path, repo_name: str):
    for p in iter_text_files(root):
        try:
            data = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        rel = str(p.relative_to(root))
        for lineno, line in enumerate(data.splitlines(), 1):
            for m in URI_RE.finditer(line):
                uri = clean_uri(m.group(0))
                yield {
                    "source_repository": repo_name,
                    "source_file": rel,
                    "source_line": lineno,
                    "protocol": protocol_of(uri),
                    "raw_config": uri,
                    "fingerprint": stable_fingerprint(uri),
                }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", action="append", nargs=2, metavar=("NAME", "PATH"), required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    seen, raw_count = {}, 0
    for name, path in args.repo:
        for row in extract(Path(path), name):
            raw_count += 1
            fp = row["fingerprint"]
            src = {"repository": row["source_repository"], "file": row["source_file"], "line": row["source_line"]}
            if fp not in seen:
                seen[fp] = {
                    "candidate_id": fp[:16],
                    "protocol": row["protocol"],
                    "raw_config": row["raw_config"],
                    "fingerprint": fp,
                    "sources": [src],
                }
            else:
                seen[fp]["sources"].append(src)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for row in seen.values():
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    print(json.dumps({"raw_configs": raw_count, "unique_configs": len(seen), "output": str(out)}))

if __name__ == "__main__":
    main()
