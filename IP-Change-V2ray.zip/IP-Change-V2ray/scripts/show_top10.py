#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys
from pathlib import Path

RED_BOLD = "\033[1;31m"
RESET = "\033[0m"

def fmt(v, suffix=""):
    return "-" if v is None else f"{v}{suffix}"

def copy_clipboard(text: str) -> bool:
    cmds = []
    if os.name == "nt": cmds = [["clip.exe"]]
    elif sys.platform == "darwin": cmds = [["pbcopy"]]
    else:
        if shutil.which("wl-copy"): cmds.append(["wl-copy"])
        if shutil.which("xclip"): cmds.append(["xclip", "-selection", "clipboard"])
        if shutil.which("xsel"): cmds.append(["xsel", "--clipboard", "--input"])
    for cmd in cmds:
        try:
            subprocess.run(cmd, input=text.encode(), check=True)
            return True
        except Exception:
            pass
    return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top10", required=True)
    ap.add_argument("--selected-dir", default="selected")
    args = ap.parse_args()
    rows = json.loads(Path(args.top10).read_text(encoding="utf-8"))
    if not rows:
        print("No qualifying Top-10 candidates.")
        raise SystemExit(1)

    ansi = sys.stdout.isatty()
    if ansi: print(RED_BOLD, end="")
    print("=" * 118)
    print("IP-CHANGE-V2RAY — TOP 10")
    print("=" * 118)
    print(f"{'#':<3} {'Proto':<10} {'Server':<28} {'Resolved IP':<16} {'Country':<10} {'Lat':>8} {'Jit':>8} {'Succ':>7} {'Mbps':>9} {'Score':>7}")
    print("-" * 118)
    for r in rows:
        print(f"{r.get('rank',''):<3} {str(r.get('protocol','-'))[:10]:<10} {str(r.get('server','-'))[:28]:<28} {str(r.get('resolved_ip', r.get('resolved_ips','-')))[:16]:<16} {str(r.get('exit_country','-'))[:10]:<10} {fmt(r.get('median_latency_ms'),'ms'):>8} {fmt(r.get('jitter_ms'),'ms'):>8} {f'{float(r.get("success_rate",0))*100:.0f}%':>7} {fmt(r.get('median_bandwidth_mbps')):>9} {fmt(r.get('score')):>7}")
    print("=" * 118)
    if ansi: print(RESET, end="")

    valid = {int(r["rank"]): r for r in rows}
    while True:
        try:
            choice = int(input(f"Choose configuration [1-{len(rows)}]: ").strip())
        except ValueError:
            continue
        if choice in valid:
            row = valid[choice]
            break

    out = Path(args.selected_dir)
    out.mkdir(parents=True, exist_ok=True)
    raw = row.get("raw_config", "")
    (out / "selected-config.txt").write_text(raw + "\n", encoding="utf-8")
    (out / "selected-metadata.json").write_text(json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print("\nSELECTED CONFIGURATION")
    for k, label in [
        ("rank","Rank"),("protocol","Protocol"),("server","Server"),("resolved_ip","Resolved IP"),
        ("exit_ip","Exit IP"),("exit_country","Country"),("exit_asn","ASN"),("median_latency_ms","Latency ms"),
        ("jitter_ms","Jitter ms"),("success_rate","Success Rate"),("median_bandwidth_mbps","Bandwidth Mbps"),("score","Score")]:
        print(f"{label}: {row.get(k, '-')}")
    print("\nConfig:\n" + raw)
    print("\nClipboard:", "copied" if raw and copy_clipboard(raw) else "not available")

if __name__ == "__main__":
    main()
