#!/usr/bin/env python3
"""Normalize common recon tool outputs into canonical CSV tables.

Designed for Claude Code skill workspaces. It is intentionally tolerant of
field changes between tool versions and preserves source-file provenance.
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def read_jsonl(path: Path):
    with path.open("r", encoding="utf-8", errors="replace") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    yield obj
            except Exception:
                continue


def read_json(path: Path):
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception:
        return None


def first(obj: dict, *keys, default=""):
    for k in keys:
        if k in obj and obj[k] not in (None, "", [], {}):
            return obj[k]
    return default


def flatten(v, sep=";") -> str:
    if v is None:
        return ""
    if isinstance(v, (str, int, float, bool)):
        return str(v)
    if isinstance(v, dict):
        return sep.join(f"{k}={flatten(val, ',')}" for k, val in v.items())
    if isinstance(v, (list, tuple, set)):
        out = []
        for x in v:
            sx = flatten(x, ",")
            if sx and sx not in out:
                out.append(sx)
        return sep.join(out)
    return str(v)


def norm_host(s: str) -> str:
    s = (s or "").strip().lower().rstrip(".")
    if s.startswith("*."):
        s = s[2:]
    if "://" in s:
        try:
            s = urlsplit(s).hostname or s
        except Exception:
            pass
    return s


def root_guess(host: str) -> str:
    # Best-effort only. Do not use this to enforce scope.
    parts = norm_host(host).split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else norm_host(host)


def normalize_url(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    try:
        p = urlsplit(url)
        host = (p.hostname or "").lower()
        if not host:
            return url
        port = p.port
        scheme = p.scheme.lower()
        netloc = host
        if port and not ((scheme == "http" and port == 80) or (scheme == "https" and port == 443)):
            netloc = f"{host}:{port}"
        path = p.path or "/"
        return urlunsplit((scheme, netloc, path, p.query, ""))
    except Exception:
        return url


def write_csv(path: Path, fieldnames: list[str], rows: list[dict], key_fields: list[str]) -> None:
    ensure_dir(path.parent)
    dedup = {}
    for row in rows:
        clean = {k: flatten(row.get(k, "")) for k in fieldnames}
        key = tuple(clean.get(k, "").lower() for k in key_fields)
        if key not in dedup:
            dedup[key] = clean
        else:
            # Merge non-empty fields and provenance rather than dropping it.
            cur = dedup[key]
            for k in fieldnames:
                nv = clean.get(k, "")
                if not nv:
                    continue
                if not cur.get(k):
                    cur[k] = nv
                elif nv != cur[k] and k in {"source", "ips", "cname", "tech", "san", "evidence"}:
                    vals = [x for x in cur[k].split(";") if x]
                    for x in nv.split(";"):
                        if x and x not in vals:
                            vals.append(x)
                    cur[k] = ";".join(vals)
    ordered = sorted(dedup.values(), key=lambda r: tuple(r.get(k, "") for k in key_fields))
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(ordered)


def norm_scope_asset(s: str) -> str:
    s = (s or "").strip().lower().rstrip(".")
    if s.startswith("http://") or s.startswith("https://"):
        try:
            s = urlsplit(s).hostname or s
        except Exception:
            pass
    return s


def existing_scope_map(tables: Path, workspace: Path | None = None) -> dict[str, str]:
    out: dict[str, str] = {}
    p = tables / "scope.csv"
    if p.exists():
        try:
            with p.open("r", encoding="utf-8", errors="replace", newline="") as f:
                for r in csv.DictReader(f):
                    a = norm_scope_asset(r.get("asset", ""))
                    if a:
                        out[a] = (r.get("scope_status") or "UNKNOWN").upper()
        except Exception:
            pass

    if workspace is not None:
        scope_dir = workspace / "00_scope"
        for filename, status in [
            ("in_scope_domains.txt", "IN_SCOPE"),
            ("out_of_scope.txt", "OUT_OF_SCOPE"),
            ("candidates.txt", "CANDIDATE"),
        ]:
            fp = scope_dir / filename
            if not fp.exists():
                continue
            for line in fp.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "/" in line and not "." in line:
                    continue
                a = norm_scope_asset(line.split()[0])
                if a:
                    out.setdefault(a, status)
    return out


def in_scope_status(host: str, scope_map: dict[str, str]) -> str:
    host = norm_host(host)
    if host in scope_map:
        return scope_map[host]
    # Wildcard rows may use *.example.com.
    for raw, status in scope_map.items():
        if raw.startswith("*."):
            base = raw[2:]
            if host == base or host.endswith("." + base):
                return status
    return "UNKNOWN"

def scope_root_guess(host: str, scope_map: dict[str, str]) -> str:
    host = norm_host(host)
    candidates = []
    for raw in scope_map:
        base = raw[2:] if raw.startswith("*.") else raw
        if base and (host == base or host.endswith("." + base)):
            candidates.append(base)
    if candidates:
        return max(candidates, key=len)
    return root_guess(host)


def parse_subfinder(raw: Path, rows: list[dict], scope_map: dict[str, str]):
    for p in raw.glob("subfinder*.jsonl"):
        for o in read_jsonl(p):
            host = norm_host(first(o, "host", "input", "domain"))
            if not host:
                continue
            rows.append({
                "root_domain": scope_root_guess(host, scope_map),
                "subdomain": host,
                "resolved": "",
                "ips": first(o, "ip"),
                "cname": "",
                "source": flatten(first(o, "sources", "source")) or p.name,
                "first_seen": first(o, "timestamp") or utcnow(),
                "scope_status": in_scope_status(host, scope_map),
                "wildcard": "",
                "cdn": "",
                "asn": "",
            })


def parse_puredns_shuffledns(raw: Path, rows: list[dict], scope_map: dict[str, str]):
    for pat in ("puredns*.txt", "shuffledns*.txt"):
        for p in raw.glob(pat):
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
                host = norm_host(line.split()[0] if line.split() else "")
                if not host or "." not in host:
                    continue
                rows.append({
                    "root_domain": scope_root_guess(host, scope_map), "subdomain": host, "resolved": "true",
                    "ips": "", "cname": "", "source": p.name, "first_seen": utcnow(),
                    "scope_status": in_scope_status(host, scope_map), "wildcard": "", "cdn": "", "asn": ""
                })


def parse_crtsh(raw: Path, rows: list[dict], scope_map: dict[str, str]):
    for p in raw.glob("crtsh*.json"):
        data = read_json(p)
        if not isinstance(data, list):
            continue
        for o in data:
            if not isinstance(o, dict):
                continue
            names = str(o.get("name_value", "")).splitlines()
            for n in names:
                host = norm_host(n)
                if not host or "." not in host:
                    continue
                rows.append({
                    "root_domain": scope_root_guess(host, scope_map), "subdomain": host, "resolved": "",
                    "ips": "", "cname": "", "source": p.name,
                    "first_seen": str(o.get("entry_timestamp", "")) or utcnow(),
                    "scope_status": in_scope_status(host, scope_map), "wildcard": "", "cdn": "", "asn": ""
                })


def parse_dnsx(raw: Path, dns_rows: list[dict], sub_rows: list[dict], scope_map: dict[str, str]):
    record_map = [
        ("A", "a"), ("AAAA", "aaaa"), ("CNAME", "cname"), ("NS", "ns"),
        ("MX", "mx"), ("TXT", "txt"), ("PTR", "ptr"), ("SRV", "srv"), ("CAA", "caa")
    ]
    for p in raw.glob("dnsx*.jsonl"):
        for o in read_jsonl(p):
            host = norm_host(first(o, "host", "input", "name"))
            if not host:
                continue
            cdn = first(o, "cdn-name", "cdn_name", "cdn")
            asn = first(o, "asn")
            resolver = first(o, "resolver")
            status = first(o, "status_code", "rcode")
            ips = []
            cnames = []
            for rtype, key in record_map:
                val = o.get(key)
                if val in (None, "", []):
                    continue
                vals = val if isinstance(val, list) else [val]
                for v in vals:
                    if rtype in {"A", "AAAA"}:
                        ips.append(str(v))
                    if rtype == "CNAME":
                        cnames.append(str(v))
                    dns_rows.append({
                        "host": host, "record_type": rtype, "value": flatten(v),
                        "status_code": status, "resolver": resolver, "cdn": cdn,
                        "asn": asn, "source": p.name,
                    })
            sub_rows.append({
                "root_domain": scope_root_guess(host, scope_map), "subdomain": host,
                "resolved": "true" if ips or cnames else "",
                "ips": ";".join(dict.fromkeys(ips)), "cname": ";".join(dict.fromkeys(cnames)),
                "source": p.name, "first_seen": first(o, "timestamp") or utcnow(),
                "scope_status": in_scope_status(host, scope_map), "wildcard": "",
                "cdn": cdn, "asn": asn,
            })


def parse_httpx(raw: Path, rows: list[dict]):
    for p in raw.glob("httpx*.jsonl"):
        for o in read_jsonl(p):
            url = normalize_url(first(o, "url", "input"))
            if not url:
                continue
            sp = urlsplit(url)
            tech = first(o, "tech", "technologies")
            cdn = first(o, "cdn_name", "cdn-name", "cdn")
            rows.append({
                "url": url,
                "host": norm_host(first(o, "host") or sp.hostname or ""),
                "scheme": first(o, "scheme") or sp.scheme,
                "port": first(o, "port") or (sp.port or (443 if sp.scheme == "https" else 80)),
                "status_code": first(o, "status_code", "status-code"),
                "title": first(o, "title"),
                "tech": tech,
                "server": first(o, "webserver", "web_server", "server"),
                "content_type": first(o, "content_type", "content-type"),
                "content_length": first(o, "content_length", "content-length"),
                "location": first(o, "location"),
                "ip": first(o, "host_ip", "ip"),
                "cname": first(o, "cname"),
                "cdn": cdn,
                "asn": first(o, "asn"),
                "favicon": first(o, "favicon"),
                "response_time": first(o, "response_time", "response-time"),
                "source": p.name,
            })


def parse_naabu(raw: Path, rows: list[dict]):
    for p in raw.glob("naabu*.jsonl"):
        for o in read_jsonl(p):
            rows.append({
                "host": norm_host(first(o, "host")),
                "ip": first(o, "ip"),
                "port": first(o, "port"),
                "protocol": first(o, "protocol", default="tcp"),
                "service": first(o, "service", "service_name"),
                "version": first(o, "version"),
                "source": p.name,
            })


def parse_tlsx(raw: Path, rows: list[dict], sub_rows: list[dict], scope_map: dict[str, str]):
    for p in raw.glob("tlsx*.jsonl"):
        for o in read_jsonl(p):
            host = norm_host(first(o, "host", "input"))
            sans = first(o, "subject_an", "subject_alt_name", "san", "dns_names")
            rows.append({
                "host": host,
                "ip": first(o, "ip"),
                "port": first(o, "port", default="443"),
                "subject_cn": first(o, "subject_cn"),
                "subject_org": first(o, "subject_org"),
                "san": sans,
                "issuer": first(o, "issuer_dn", "issuer_cn", "issuer"),
                "serial": first(o, "serial"),
                "not_before": first(o, "not_before"),
                "not_after": first(o, "not_after"),
                "self_signed": first(o, "self_signed", "self-signed"),
                "expired": first(o, "expired"),
                "mismatched": first(o, "mismatched"),
                "fingerprint_sha256": first(o, "fingerprint_hash", "sha256", "certificate_sha256"),
                "source": p.name,
            })
            vals = sans if isinstance(sans, list) else re.split(r"[;,\s]+", str(sans)) if sans else []
            for san in vals:
                sh = norm_host(str(san))
                if not sh or "." not in sh:
                    continue
                sub_rows.append({
                    "root_domain": scope_root_guess(sh, scope_map), "subdomain": sh, "resolved": "",
                    "ips": "", "cname": "", "source": f"{p.name}:certificate_san",
                    "first_seen": first(o, "timestamp") or utcnow(),
                    "scope_status": in_scope_status(sh, scope_map), "wildcard": "", "cdn": "", "asn": ""
                })


def interesting_url(url: str) -> str:
    s = url.lower()
    terms = [
        "api", "admin", "internal", "debug", "swagger", "openapi", "graphql", "actuator",
        "metrics", "health", "config", "backup", "staging", "stage", "dev", "test",
        "upload", "export", "import", "callback", "redirect", "webhook"
    ]
    return "true" if any(t in s for t in terms) or "?" in url else ""


def add_url(url: str, source: str, rows: list[dict], method="", status_code=""):
    url = normalize_url(url)
    if not url:
        return
    try:
        p = urlsplit(url)
    except Exception:
        return
    ext = ""
    bn = os.path.basename(p.path)
    if "." in bn:
        ext = bn.rsplit(".", 1)[-1].lower()[:20]
    rows.append({
        "url": url, "host": norm_host(p.hostname or ""), "path": p.path or "/",
        "query": p.query, "extension": ext, "source": source,
        "status_code": status_code, "method": method, "interesting": interesting_url(url),
    })


def parse_urls(raw: Path, rows: list[dict]):
    for pat in ("waybackurls*.txt", "gau*.txt"):
        for p in raw.glob(pat):
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.strip().startswith(("http://", "https://")):
                    add_url(line.strip(), p.name, rows)
    for p in raw.glob("katana*.jsonl"):
        for o in read_jsonl(p):
            # Current Katana JSONL commonly stores endpoint under request.endpoint.
            req = o.get("request") if isinstance(o.get("request"), dict) else {}
            endpoint = first(req, "endpoint", "url") or first(o, "url", "endpoint")
            if endpoint:
                add_url(str(endpoint), p.name, rows, method=str(first(req, "method")))


def parse_ffuf(raw: Path, content_rows: list[dict]):
    for p in raw.glob("ffuf*.json"):
        data = read_json(p)
        if not isinstance(data, dict):
            continue
        for r in data.get("results", []) if isinstance(data.get("results"), list) else []:
            if not isinstance(r, dict):
                continue
            url = first(r, "url")
            content_rows.append({
                "base_url": "", "discovered_url": url,
                "path": urlsplit(url).path if url else "",
                "status_code": first(r, "status"), "content_length": first(r, "length"),
                "redirect": first(r, "redirectlocation"), "tool": "ffuf", "source_file": p.name,
            })


def parse_gobuster(raw: Path, content_rows: list[dict]):
    # Best-effort parser; keep source text when URL is not available.
    rx = re.compile(r"(?P<path>/\S+)\s+\(Status:\s*(?P<status>\d+).*?(?:Size:\s*(?P<size>\d+))?", re.I)
    for p in raw.glob("gobuster_dir*.txt"):
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            m = rx.search(line)
            if m:
                content_rows.append({
                    "base_url": "", "discovered_url": "", "path": m.group("path"),
                    "status_code": m.group("status"), "content_length": m.group("size") or "",
                    "redirect": "", "tool": "gobuster", "source_file": p.name,
                })


def parse_nuclei(raw: Path, rows: list[dict]):
    for p in raw.glob("nuclei*.jsonl"):
        for o in read_jsonl(p):
            info = o.get("info") if isinstance(o.get("info"), dict) else {}
            rows.append({
                "type": first(o, "template-id", "template_id") or first(info, "name"),
                "severity": first(info, "severity"),
                "asset": first(o, "matched-at", "matched_at", "host"),
                "evidence": first(o, "matcher-name", "matcher_name") or first(o, "extracted-results", "extracted_results"),
                "source": p.name,
                "status": "UNVERIFIED",
                "notes": "Scanner match; validate manually before reporting.",
            })



def build_sources_errors(ws: Path, tables: Path):
    rows = []
    log = ws / "logs" / "commands.tsv"
    if log.exists():
        try:
            with log.open("r", encoding="utf-8", errors="replace", newline="") as f:
                reader = csv.DictReader(f, delimiter="\t")
                for r in reader:
                    exit_code = str(r.get("exit_code", ""))
                    kind = "error" if exit_code not in ("", "0") else "command"
                    rows.append({
                        "timestamp": r.get("timestamp_utc", ""),
                        "kind": kind,
                        "phase": r.get("phase", ""),
                        "tool": r.get("tool", ""),
                        "target": r.get("target_or_input", ""),
                        "command_or_error": r.get("command", ""),
                        "source_file": r.get("output_file", ""),
                    })
        except Exception:
            pass
    write_csv(tables / "sources_errors.csv",
              ["timestamp","kind","phase","tool","target","command_or_error","source_file"],
              rows, ["timestamp","tool","target","command_or_error"])


def csv_rows(path: Path):
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        return list(csv.DictReader(f))


def build_text_reports(ws: Path, tables: Path):
    report = ws / "report"
    ensure_dir(report)
    subs = csv_rows(tables / "subdomains.csv")
    http = csv_rows(tables / "http.csv")
    ports = csv_rows(tables / "ports.csv")
    tls = csv_rows(tables / "tls.csv")
    urls = csv_rows(tables / "urls.csv")
    findings = csv_rows(tables / "findings.csv")
    roots = csv_rows(tables / "root_domains.csv")

    in_scope_hosts = sorted({r.get("subdomain", "").strip() for r in subs
                             if r.get("subdomain", "").strip() and r.get("scope_status", "").upper() == "IN_SCOPE"})
    live_urls = sorted({r.get("url", "").strip() for r in http if r.get("url", "").strip()})
    open_ports = sorted({f"{(r.get('ip') or r.get('host') or '').strip()}:{str(r.get('port','')).strip()}"
                         for r in ports if (r.get("ip") or r.get("host")) and r.get("port")})
    interesting = sorted({r.get("url", "").strip() for r in urls
                          if r.get("url", "").strip() and r.get("interesting", "").lower() == "true"})

    (report / "all_in_scope_hosts.txt").write_text("\n".join(in_scope_hosts) + ("\n" if in_scope_hosts else ""), encoding="utf-8")
    (report / "live_urls.txt").write_text("\n".join(live_urls) + ("\n" if live_urls else ""), encoding="utf-8")
    (report / "open_ports.txt").write_text("\n".join(open_ports) + ("\n" if open_ports else ""), encoding="utf-8")
    (report / "interesting_urls.txt").write_text("\n".join(interesting) + ("\n" if interesting else ""), encoding="utf-8")

    unique_ips = {r.get("ip", "").strip() for r in http if r.get("ip", "").strip()}
    candidates = sorted({r.get("subdomain", "").strip() for r in subs
                         if r.get("subdomain", "").strip() and r.get("scope_status", "").upper() == "CANDIDATE"})
    lines = [
        "# Recon Summary", "",
        f"- Root-domain records: {len(roots)}",
        f"- Subdomains: {len(subs)}",
        f"- Confirmed in-scope hosts: {len(in_scope_hosts)}",
        f"- Live HTTP URLs: {len(live_urls)}",
        f"- Unique HTTP IPs: {len(unique_ips)}",
        f"- Open port records: {len(ports)}",
        f"- TLS records: {len(tls)}",
        f"- Historical/crawled URLs: {len(urls)}",
        f"- Interesting URL leads: {len(interesting)}",
        f"- Recon findings (unverified unless manually validated): {len(findings)}",
        f"- Candidate assets awaiting scope confirmation: {len(candidates)}",
        "",
        "## Candidate assets",
    ]
    lines += [f"- {x}" for x in candidates[:100]] or ["- None recorded"]
    if len(candidates) > 100:
        lines.append(f"- ... and {len(candidates)-100} more (see tables/subdomains.csv)")
    lines += [
        "",
        "## Interpretation",
        "Candidate domains, certificate SANs, PTR names, shared infrastructure, acquisition domains, and ASN/CIDR ownership clues require scope confirmation before active probing.",
        "Scanner matches should be manually validated before being treated as reportable vulnerabilities.",
    ]
    (report / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workspace", default=".")
    args = ap.parse_args()

    ws = Path(args.workspace).resolve()
    raw = ws / "raw"
    tables = ws / "tables"
    ensure_dir(raw)
    ensure_dir(tables)

    scope_map = existing_scope_map(tables, ws)

    sub_rows, dns_rows, http_rows, port_rows, tls_rows = [], [], [], [], []
    url_rows, content_rows, finding_rows = [], [], []

    parse_subfinder(raw, sub_rows, scope_map)
    parse_crtsh(raw, sub_rows, scope_map)
    parse_puredns_shuffledns(raw, sub_rows, scope_map)
    parse_dnsx(raw, dns_rows, sub_rows, scope_map)
    parse_httpx(raw, http_rows)
    parse_naabu(raw, port_rows)
    parse_tlsx(raw, tls_rows, sub_rows, scope_map)
    parse_urls(raw, url_rows)
    parse_ffuf(raw, content_rows)
    parse_gobuster(raw, content_rows)
    parse_nuclei(raw, finding_rows)

    write_csv(tables / "subdomains.csv",
              ["root_domain","subdomain","resolved","ips","cname","source","first_seen","scope_status","wildcard","cdn","asn"],
              sub_rows, ["subdomain"])
    write_csv(tables / "dns.csv",
              ["host","record_type","value","status_code","resolver","cdn","asn","source"],
              dns_rows, ["host","record_type","value"])
    write_csv(tables / "http.csv",
              ["url","host","scheme","port","status_code","title","tech","server","content_type","content_length","location","ip","cname","cdn","asn","favicon","response_time","source"],
              http_rows, ["url"])
    write_csv(tables / "ports.csv",
              ["host","ip","port","protocol","service","version","source"],
              port_rows, ["ip","host","protocol","port"])
    write_csv(tables / "tls.csv",
              ["host","ip","port","subject_cn","subject_org","san","issuer","serial","not_before","not_after","self_signed","expired","mismatched","fingerprint_sha256","source"],
              tls_rows, ["host","ip","port","fingerprint_sha256","serial"])
    write_csv(tables / "urls.csv",
              ["url","host","path","query","extension","source","status_code","method","interesting"],
              url_rows, ["url"])
    write_csv(tables / "content.csv",
              ["base_url","discovered_url","path","status_code","content_length","redirect","tool","source_file"],
              content_rows, ["source_file","discovered_url","path","status_code"])
    write_csv(tables / "findings.csv",
              ["type","severity","asset","evidence","source","status","notes"],
              finding_rows, ["type","asset","evidence"])

    build_sources_errors(ws, tables)
    build_text_reports(ws, tables)

    print(f"Normalized workspace: {ws}")
    for name in ["subdomains.csv","dns.csv","http.csv","ports.csv","tls.csv","urls.csv","content.csv","findings.csv"]:
        p = tables / name
        count = max(sum(1 for _ in p.open("r", encoding="utf-8", errors="replace")) - 1, 0) if p.exists() else 0
        print(f"  {name}: {count} rows")


if __name__ == "__main__":
    main()
