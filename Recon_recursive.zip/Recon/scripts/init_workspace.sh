#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-target}"
ROOT="${2:-recon/${TARGET}}"

mkdir -p "$ROOT"/{00_scope,01_roots,02_subdomains,03_dns,04_http,05_ports,06_tls,07_urls,08_content,09_findings,raw,tables,logs,state,report}

if [[ ! -f "$ROOT/logs/commands.tsv" ]]; then
  printf 'timestamp_utc\tphase\ttool\ttarget_or_input\tcommand\texit_code\toutput_file\n' > "$ROOT/logs/commands.tsv"
fi

for tool in subfinder dnsx httpx naabu nmap tlsx katana gobuster ffuf nuclei mapcidr puredns shuffledns waybackurls gau jq curl dig openssl; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf '[OK]      %s -> %s\n' "$tool" "$(command -v "$tool")"
  else
    printf '[MISSING] %s\n' "$tool"
  fi
done

printf '\nWorkspace: %s\n' "$ROOT"
