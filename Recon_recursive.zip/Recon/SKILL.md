---
name: bug-bounty-recon
description: Full bug bounty reconnaissance workflow for authorized programs, with wide passive peripheral discovery and exhaustive phase execution. Use it to map root domains, subdomains, DNS, CDN/origin candidates, CIDRs/ASNs, HTTP services, ports, TLS certificates, virtual hosts, historical URLs, crawled endpoints, and low-impact recon findings; preserve raw evidence; iterate pivots; and produce clean TXT/JSONL/CSV plus a readable Markdown report.
---

# Bug Bounty Recon

## Purpose

Use this skill for reconnaissance on bug bounty, VDP, pentest, or lab targets where the user has authorization. Build an evidence-backed attack-surface inventory, not an exploit chain.

The skill has five priorities, in this order:

1. **Stay inside the confirmed authorization boundary for active probing.**
2. **Run every applicable reconnaissance phase to completion; do not stop after partial success.**
3. **Preserve raw data and provenance so every derived asset is explainable.**
4. **Maximize useful attack-surface coverage through iterative pivots, including wide passive peripheral discovery.**
5. **Finish with human-readable, deduplicated output and a full, detailed Markdown report.**

Read `REFERENCE.md` when you need tool-specific commands, install notes, detailed pivots, or reporting schemas. Use the helper scripts in `scripts/` when possible instead of rebuilding parsers/reporting from scratch.

---


## IMPORTANT — Full-run completion rule

A requested full/deep recon is not complete after finding a few live hosts or interesting endpoints. **Every applicable phase in this skill must be attempted and carried through patiently.**

Rules:

- Run phases in order, while feeding discoveries forward into later phases.
- Do not stop because one phase produced interesting results. Continue through the remaining phases.
- If a tool is missing or fails, try a compatible alternative when available and record the failure plus fallback.
- Retry transient network/tool failures according to the configured retry rule.
- Re-run normalization after major new pivots so later phases consume the newest inventory.
- Continue iterative recon passes until the workflow converges: no meaningful new authorized assets, services, URLs, or pivots are being produced.
- A phase may be marked `BLOCKED` only for a real hard blocker such as missing authorization, an unavailable required dependency with no alternative, or a target/program restriction. Record the exact reason in the report.
- Never silently skip a phase. Every phase must end as `COMPLETED`, `COMPLETED_WITH_FALLBACK`, `NO_DATA`, or `BLOCKED`, with evidence/logging.

This rule is a completion requirement, not permission to exceed authorization or program restrictions.

---

## User-configurable global execution rules

Edit this block whenever you want to change how all compatible tools run:

```yaml
execution_rules:
  threads: 2
  delay_ms: 30
  timeout_seconds: 15
  retries: 1
  max_rps: null
  seclists_required_for_content_discovery: true
  seclists_path: auto
  recursive_content_discovery: true
  recursive_max_depth: null
  extra_rules: []
```

Interpretation:

- `threads`: use this concurrency/thread value for tools that expose a thread/concurrency flag.
- `delay_ms`: add at least this per-request/per-worker delay when the tool supports a delay flag.
- `timeout_seconds`: use as the network/request timeout when a compatible flag exists.
- `retries`: retry transient failures up to this many times when safe and useful.
- `max_rps`: when set, it is an additional requests-per-second ceiling.
- `seclists_required_for_content_discovery`: when `true`, directory and filename brute-force phases must use wordlists from the SecLists repository unless the user explicitly supplies another list.
- `seclists_path`: `auto` means detect common locations such as `$SECLISTS_PATH`, `/usr/share/seclists`, `/usr/share/SecLists`, `/opt/SecLists`, or a local cloned `SecLists/` directory. If SecLists is missing, record the blocker and install/clone it when the environment and user authorization permit.
- `recursive_content_discovery`: when `true`, every newly discovered directory becomes a new base path for another directory + filename brute-force pass.
- `recursive_max_depth`: optional recursion-depth ceiling. `null` means continue until no new directories are discovered, subject to authorization, program limits, and global execution rules.
- `extra_rules`: free-form rules that Claude must apply to the whole run.
- If a tool cannot express an exact rule, translate it to the closest supported control without inventing unsupported flags, and document the translation.
- Program/target restrictions and lower published rate limits override these values.

Example translations for the defaults:

```text
Gobuster / FFUF: threads/concurrency = 2, delay >= 30ms where supported
Nmap: avoid aggressive parallelism; keep host-group/parallelism conservative
HTTPX / Katana / Nuclei / Naabu: map to supported concurrency/rate-limit controls
Subfinder/passive APIs: respect provider rate limits first
```

---

## Non-negotiable authorization rules

Before any active request, establish the scope from the user's program page, supplied scope file, or explicit instructions.

Classify every asset as one of:

- `IN_SCOPE` — explicitly allowed by the program/user.
- `OUT_OF_SCOPE` — explicitly excluded.
- `CANDIDATE` — possibly related/owned, but not yet authorized.
- `UNKNOWN` — insufficient evidence.

### Wide passive peripheral discovery is allowed; active promotion is not automatic

Acquisitions, reverse-WHOIS matches, certificate SANs, PTR records, ASN/CIDR ownership, shared infrastructure, copyright strings, source-code mentions, and favicon matches are **discovery evidence only**. They do not grant authorization.

For `CANDIDATE`, `UNKNOWN`, or explicitly non-scope related assets:

- Perform broad **passive** relationship discovery when useful: acquisitions, subsidiaries, reverse-WHOIS, CT logs, public ASN/BGP data, public search engines, passive DNS/history, public code/search indexes, and published metadata.
- Follow passive relationships even when the asset itself is not currently in scope, because they may reveal additional authorized roots, subdomains, certificates, historical origin clues, or ownership evidence.
- Do not brute-force DNS against it, port-scan it, crawl it, fuzz it, run Gobuster/FFUF, run Nuclei, or otherwise actively probe it until authorization is confirmed.
- Add it to the report with the relationship evidence and its actual scope status.
- If a passive pivot leads back to a confirmed authorized asset, continue the full active workflow on that authorized asset.

### Respect program restrictions

Parse and honor:

- explicitly excluded hosts, paths, IPs, ports, countries, and third parties;
- scanner/automation restrictions;
- request-rate restrictions;
- required traffic-identification headers or User-Agent;
- prohibited actions such as login brute force, destructive testing, DoS, data access, or social engineering.

This skill is reconnaissance-only by default. Do not perform exploitation, credential attacks, destructive testing, data modification, persistence, or denial-of-service behavior.

---

## Inputs

Prefer these inputs when available:

- Program name and program URL
- Confirmed root domains / wildcard scopes
- Explicit CIDRs / ASNs in scope
- Explicit exclusions
- Rate limits / automation policy
- Bug-bounty identification header or User-Agent
- Wordlist locations
- API keys already configured for passive providers (Subfinder, Censys, Shodan, etc.)

If a program scope file is supplied, parse it first and write a normalized copy to `00_scope/scope.csv`.

---

## Execution modes

Use the least aggressive mode that satisfies the user.

### `passive`

No direct probing of targets. Use public datasets, certificate transparency, search engines, passive providers, historical indexes, and user-provided files.

### `standard` — default

Passive recon plus conservative DNS resolution, HTTP probing, crawling, targeted content discovery, and top/common port discovery on confirmed in-scope assets.

### `deep`

Use only when the user asks for deep/full recon and the program permits automation. May include DNS brute force/permutations, broader port scanning on small confirmed ranges, vhost discovery, more comprehensive crawling, and low-impact Nuclei recon checks. Still no exploitation.

---

## Workspace contract

Create one workspace per target/program. Prefer:

```text
recon/<program-or-target>/
├── 00_scope/
├── 01_roots/
├── 02_subdomains/
├── 03_dns/
├── 04_http/
├── 05_ports/
├── 06_tls/
├── 07_urls/
├── 08_content/
├── 09_findings/
├── raw/
├── tables/
├── logs/
├── state/
└── report/
```

Never overwrite raw evidence. Put tool-native output in `raw/` and normalized/deduplicated tables in `tables/`.

Use ISO-8601 UTC timestamps where possible.

For every command, append a row to `logs/commands.tsv` with:

```text
timestamp_utc	phase	tool	target_or_input	command	exit_code	output_file
```

Maintain `state/phases.csv` throughout the run:

```text
phase,status,started_utc,finished_utc,tools,notes
```

Allowed statuses: `PENDING`, `RUNNING`, `COMPLETED`, `COMPLETED_WITH_FALLBACK`, `NO_DATA`, `BLOCKED`. Update the row when each phase starts and finishes.

Do not put secrets/API keys into logs.

---

# Recon workflow

## Phase 0 — Scope normalization and guardrails

1. Normalize scope into exact roots, wildcard roots, IP/CIDR ranges, and exclusions.
2. Create machine-checkable lists:
   - `00_scope/in_scope_domains.txt`
   - `00_scope/in_scope_cidrs.txt`
   - `00_scope/out_of_scope.txt`
   - `00_scope/candidates.txt`
3. Before any active command, filter its targets through these lists.
4. Track third-party SaaS/CDN/cloud infrastructure separately. Passive relationship mapping is allowed, but active probing requires explicit authorization.
5. If scope is ambiguous, continue passive discovery broadly and report the ambiguity; active probing remains limited to confirmed authorization.

Recommended columns for `tables/scope.csv`:

```text
asset,asset_type,scope_status,source,evidence,notes
```

---

## Phase 1 — Root-domain / company-property discovery

Goal: map company properties and related root domains as broadly as possible through passive evidence, then identify which discovered assets are confirmed for active testing.

### Sources and pivots

Use a combination of:

- acquisition / subsidiary research;
- public company databases such as Crunchbase and Tracxn when accessible;
- reverse-WHOIS / domain-property services such as Website Informer and ViewDNS;
- certificate transparency and certificate subject organization fields;
- search engines;
- hunter writeups / public disclosure reports;
- company copyright/legal text reused across web properties;
- official corporate pages, investor pages, press releases, and security-team clarification.

Useful search patterns, replacing the company name:

```text
"COMPANY has acquired"
"acquired by COMPANY"
"COMPANY acquisition list"
"COMPANY. All Rights Reserved." -inurl:company-domain.example
```

Record for every candidate:

```text
root_domain,relation,evidence_url,evidence_summary,scope_status,first_seen
```

Do not automatically actively scan an acquisition or subsidiary domain; keep following it passively for ownership and pivot evidence.

---

## Phase 2 — Subdomain discovery

Use several independent sources and merge them. Preserve source attribution.

### 2.1 Passive enumeration with Subfinder

For a confirmed root:

```bash
subfinder -d "$ROOT" -all -oJ -cs -o "raw/subfinder_${ROOT}.jsonl"
```

For multiple roots:

```bash
subfinder -dL 00_scope/in_scope_domains.txt -all -oJ -cs -o raw/subfinder_all.jsonl
```

If provider keys are not configured, continue with available sources; do not fail the whole run.

### 2.2 Certificate transparency

Use crt.sh or another CT source. Extract DNS SANs, normalize lowercase, remove leading `*.`, and scope-check every hostname before active use.

Example passive query:

```bash
curl -fsS "https://crt.sh/?q=%25.${ROOT}&output=json" > "raw/crtsh_${ROOT}.json"
```

### 2.3 Passive providers / search sources

When configured and permitted, use:

- Censys
- Shodan
- ProjectDiscovery Chaos
- GitHub code search
- Sourcegraph
- AbuseIPDB context
- public subdomain datasets
- favicon hash + internet search engines

Do not scrape logged-in/paid services in ways that bypass their controls.

### 2.4 Discover hostnames from web content

From confirmed live in-scope pages, extract:

- CSP hostnames
- script `src` / link `href`
- DOM URLs
- redirects
- API base URLs
- WebSocket hosts
- absolute URLs embedded in JavaScript/HTML

HTTPX JSON plus `-extract-fqdn` can help capture body/header hostnames. Scope-check all extracted names.

### 2.5 DNS brute force — active, standard/deep only

Prefer wildcard-aware resolvers.

With PureDNS:

```bash
puredns bruteforce "$DNS_WORDLIST" "$ROOT" \
  --write "raw/puredns_bruteforce_${ROOT}.txt"
```

With ShuffleDNS:

```bash
shuffledns -d "$ROOT" -w "$DNS_WORDLIST" -r "$RESOLVERS" \
  -mode bruteforce -silent -o "raw/shuffledns_bruteforce_${ROOT}.txt"
```

Use lower request rates or smaller wordlists when the program restricts automation.

### 2.6 Dynamic permutations

Only after passive results exist. Derive environment/region/service tokens from discovered names (for example `dev`, `stage`, `api`, `us-east`) and use a permutation tool/wordlist. Resolve candidates with wildcard-aware DNS and deduplicate.

Avoid blindly generating huge Cartesian products.

---

## Phase 3 — DNS resolution, records, ASN/CDN context

### 3.1 Resolve and enrich with DNSx

Feed only confirmed in-scope hostnames:

```bash
dnsx -l tables/subdomains.txt \
  -a -aaaa -cname -ns -mx -txt -cdn -asn -re -json \
  -o raw/dnsx.jsonl
```

Useful DNS fields:

- A / AAAA
- CNAME
- NS
- MX / TXT
- response/rcode
- resolver
- CDN name/type
- ASN

### 3.2 Resolver strategy

Use stable resolvers and validate wildcard-heavy results. If the organization's authoritative nameserver is publicly reachable and the program permits it, it can be useful for authoritative answers; do not assume that using it bypasses a CDN or reveals an origin.

The notes supplied with this skill mention these example resolvers:

```text
8.8.4.4
129.250.35.251
208.67.222.222
```

Prefer a curated resolver list for mass resolution and trusted resolvers for validation.

### 3.3 CDN / WAF classification

Do **not** delete CDN-fronted hosts from the master inventory. Instead:

- mark `cdn=true` and the provider;
- de-prioritize them for origin-IP port scanning;
- keep them for HTTP/content/certificate recon if they are in scope;
- prioritize confirmed non-CDN IPs for direct service discovery.

For Cloudflare-specific IP matching, a current CIDR list can be checked with `mapcidr`, for example:

```bash
curl -fsS https://www.cloudflare.com/ips-v4 -o state/cloudflare_ipv4.txt
printf '%s\n' "$IP" | mapcidr -mi state/cloudflare_ipv4.txt -silent
```

Do not treat “not in Cloudflare ranges” as proof of origin ownership.

### 3.4 PTR enumeration

PTR can find naming clues on explicitly in-scope IP/CIDR ranges. Every returned hostname must be scope-checked before further probing.

---

## Phase 4 — HTTP service discovery and enrichment

HTTPX is the primary HTTP probe.

Use structured output:

```bash
httpx -l tables/resolved_hosts.txt -silent -json \
  -sc -cl -ct -location -title -server -td -ip -cname -asn -cdn \
  -favicon -rt \
  -o raw/httpx.jsonl
```

If the program requires an identification header, add it exactly as required, for example:

```bash
-H "X-Bug-Bounty: HANDLE"
```

Do not invent traffic-identification values.

Prefer a legitimate, stable User-Agent and conservative concurrency/rate settings. If the target is fragile or the policy specifies a rate, honor the lower limit.

Store at least:

```text
url,host,scheme,port,status_code,title,tech,server,content_type,content_length,
location,ip,cname,cdn,asn,favicon,response_time,source
```

Interesting but non-conclusive signals include:

- unusual status/redirect behavior;
- forgotten titles (`dev`, `staging`, `jenkins`, `grafana`, etc.);
- uncommon technologies;
- non-CDN direct IPs;
- default pages;
- admin/API naming;
- different favicon clusters.

Do not label these as vulnerabilities without validation.

---

## Phase 5 — CIDR and ASN discovery

This phase has two separate concepts:

1. **Ownership discovery** — passive research that may create candidates.
2. **Active CIDR scanning** — allowed only for CIDRs explicitly in scope.

### Passive ASN/CIDR sources

Use public sources such as:

- BGPView
- Hurricane Electric BGP Toolkit (`bgp.he.net`)
- RIR/WHOIS data
- Censys/Shodan context

Store:

```text
asn,organization,cidr,source,scope_status,notes
```

A company name in WHOIS or BGP metadata is not sufficient by itself to actively scan a range under a bug bounty program.

---

## Phase 6 — Port and service discovery

### 6.1 Fast discovery with Naabu

For many hosts, prefer top ports or a focused web/service port list.

Common web-oriented list from the supplied notes:

```bash
naabu -list tables/non_cdn_hosts.txt \
  -p 80,8000,8080,8880,2052,2082,2086,2095,443,2053,2083,2087,2096,8443,10443 \
  -silent -json -o raw/naabu_web.jsonl
```

For larger target sets:

```bash
naabu -list tables/non_cdn_hosts.txt -top-ports 100 -rate 200 -json -o raw/naabu_top100.jsonl
```

For a small, explicitly in-scope range where the program allows broad scanning:

```bash
naabu -list 00_scope/in_scope_cidrs.txt -p - -rate 200 -json -o raw/naabu_full.jsonl
```

Use `-exclude-cdn` when appropriate for broad port scanning, but do not use it to remove CDN hosts from the overall recon inventory.

### 6.2 Validation / service versions with Nmap

Use Nmap selectively on ports already discovered, not as the first mass scanner:

```bash
nmap -sT -sV -Pn -n -p "$PORTS" "$HOST_OR_IP" -oA "raw/nmap_${SAFE_NAME}"
```

Relevant switches from the notes: `-sV`, `-sT`, `-Pn`, `-n`.

Avoid UDP scans, intrusive NSE categories, or large unrestricted sweeps unless explicitly requested and authorized.

---

## Phase 7 — TLS / certificate mining

Goal: obtain certificate metadata and discover **candidate** DNS names/properties.

### TLSx

For confirmed in-scope hosts/IPs:

```bash
tlsx -l tables/tls_targets.txt -json -san -cn -so -serial \
  -o raw/tlsx.jsonl
```

Useful certificate fields:

- issuer
- subject DN
- subject CN
- subject organization
- SANs
- serial
- validity dates
- fingerprint
- self-signed / expired / mismatched indicators

Certificate SAN/CN names are discovery evidence. Scope-check them before any active follow-up.

### OpenSSL spot check

For manual validation:

```bash
openssl s_client -connect "$HOST:443" -servername "$HOST" -showcerts </dev/null 2>/dev/null \
  | openssl x509 -noout -issuer -subject -serial -dates -ext subjectAltName
```

### CIDR certificate search

On an explicitly in-scope CIDR, a useful flow is:

```text
CIDR -> TLS ports -> certificate SAN/CN -> candidate domains/subdomains -> scope check
```

This mirrors the wide-recon notes, but the scope check is mandatory before follow-up.

---

## Phase 8 — Virtual-host discovery

Run only against confirmed in-scope hosts/IPs where vhost testing is permitted.

### Gobuster vhost

```bash
gobuster vhost -u "https://$HOST" --append-domain \
  -w "$VHOST_WORDLIST" -t "${THREADS:-2}" --delay "${DELAY_MS:-30}ms" \
  -o "raw/gobuster_vhost_${SAFE_NAME}.txt"
```

### FFUF Host-header alternative

Use a conservative rate and filter wildcard/default responses. Do not send hostnames outside the authorized root.

Keep discovered vhosts as candidates until they resolve/validate and are confirmed in scope.

---

## Phase 9 — Historical URLs and crawling

### 9.1 Historical indexes

Use both Wayback and GAU if installed:

```bash
cat 00_scope/in_scope_domains.txt | waybackurls > raw/waybackurls.txt
```

For GAU, include subdomains only when the wildcard scope allows it. Save raw output separately.

Historical URLs may reference dead/out-of-scope third parties; scope-filter before active requests.

### 9.2 Katana crawling

For confirmed live URLs:

```bash
katana -list tables/live_urls.txt -d 3 -jc -kf robotstxt,sitemapxml \
  -jsonl -silent -o raw/katana.jsonl
```

Use host rate limits when needed. Do not enable automatic form filling by default.

Extract and normalize:

- paths
- query parameter names
- JavaScript files
- API endpoints
- form actions (do not submit forms automatically)
- WebSocket URLs
- referenced hostnames

---

## Phase 10 — Content discovery

### IMPORTANT — SecLists is required by default

For **directory brute forcing and filename brute forcing**, use the **SecLists repository** as the default/required wordlist source whenever:

```yaml
seclists_required_for_content_discovery: true
```

Use:

```text
SecLists/Discovery/Web-Content/
```

Auto-detect the SecLists root in this order:

```bash
if [ -n "${SECLISTS_PATH:-}" ] && [ -d "$SECLISTS_PATH" ]; then
  SECLISTS="$SECLISTS_PATH"
elif [ -d /usr/share/seclists ]; then
  SECLISTS=/usr/share/seclists
elif [ -d /usr/share/SecLists ]; then
  SECLISTS=/usr/share/SecLists
elif [ -d /opt/SecLists ]; then
  SECLISTS=/opt/SecLists
elif [ -d ./SecLists ]; then
  SECLISTS=./SecLists
else
  SECLISTS=""
fi
```

Do not silently replace SecLists with an unrelated generic wordlist when this rule is enabled. If SecLists is unavailable, record the issue and obtain/install the repository only when the environment and authorization permit.

### Required directory/file separation

### CRITICAL — recursively recon every discovered directory

If a new directory is discovered, **always recurse into it** when:

```yaml
recursive_content_discovery: true
```

Required behavior:

```text
https://test.com/
    ↓ directory + file brute force
https://test.com/test1/
    ↓ directory + file brute force
https://test.com/test1/admin/
    ↓ directory + file brute force
https://test.com/test1/admin/api/
    ↓ directory + file brute force
...
```

Every discovered directory becomes a **new content-discovery root**.

For each new directory:

1. Normalize the URL and remove obvious duplicates.
2. Confirm it belongs to the same authorized target/service.
3. Queue it if it has not already been processed.
4. Run the configured SecLists **directory brute-force pass** against that directory.
5. Run the configured SecLists **filename brute-force pass** against that directory.
6. Add every newly discovered child directory back to the recursion queue.
7. Repeat until the queue is empty, or `recursive_max_depth` is reached when a depth limit is explicitly configured.
8. Do **not** stop recursion simply because an interesting file, admin panel, API route, or vulnerability-looking endpoint was found.
9. Preserve parent/child relationships so the final report shows where each path was discovered.

Conceptual queue logic:

```text
queue = ["/"]
visited = set()

while queue is not empty:
    current = queue.pop()

    if current already visited:
        continue

    run directory brute force on current
    run file brute force on current
    mark current visited

    for each newly discovered directory:
        if not visited:
            queue.push(new_directory)
```

Example:

```text
Initial target:
https://test.com/

Found:
https://test.com/test1/

Mandatory next step:
https://test.com/test1/FUZZ
    -> directory brute force
    -> filename brute force

If that finds:
https://test.com/test1/private/

Mandatory next step:
https://test.com/test1/private/FUZZ
    -> directory brute force
    -> filename brute force
```

### Recursive-depth handling

Track depth explicitly:

```text
/                         depth 0
/test1/                   depth 1
/test1/private/           depth 2
/test1/private/api/       depth 3
```

When `recursive_max_depth: null`, continue until **no unvisited newly discovered directories remain**.

When a numeric depth is configured, do not enqueue child directories deeper than that value.

### Recursion safety and deduplication

Maintain at least:

```text
normalized_url
parent_url
path
depth
status_code
content_length
redirect_location
tool
wordlist
discovered_from
first_seen_utc
processed
```

Avoid infinite recursion caused by:

```text
redirect loops
equivalent slash variants
URL encoding variants
case-only duplicates where the server is case-insensitive
self-referential paths
calendar/date traps
incrementing numeric paths
session IDs
cache-busting parameters
```

Canonicalize paths before queueing them, and honor the same authorization and rate/concurrency rules used everywhere else.

The recursion is considered complete only when:

```text
all queued directories have been processed
AND
no new eligible directories were discovered
```



Run directory and filename brute forcing as **separate passes**.

Recommended SecLists progression:

```text
DIRECTORIES

baseline:
  Discovery/Web-Content/common.txt
  Discovery/Web-Content/raft-small-directories.txt

standard:
  Discovery/Web-Content/raft-medium-directories.txt
  Discovery/Web-Content/combined_directories.txt

deep / prioritized targets:
  Discovery/Web-Content/raft-large-directories.txt
  Discovery/Web-Content/directory-list-2.3-medium.txt
  larger SecLists directory lists when justified


FILES

baseline:
  Discovery/Web-Content/raft-small-files.txt

standard:
  Discovery/Web-Content/raft-medium-files.txt

deep / prioritized targets:
  Discovery/Web-Content/raft-large-files.txt
  Discovery/Web-Content/combined_words.txt when context supports it
```

Also select **technology-specific SecLists wordlists** when fingerprints justify them, including lists for APIs, GraphQL, IIS, Apache, Java/J2EE, backup/config files, frameworks, CMSs, and other matching technologies under `Discovery/Web-Content/`.

For a requested full/deep recon:

1. Run a baseline SecLists **directory** pass against every confirmed authorized live HTTP service.
2. Run a baseline SecLists **filename** pass against every confirmed authorized live HTTP service.
3. **Every newly discovered directory must be recursively queued and receive its own directory + filename brute-force passes.**
4. Continue recursive discovery until no new eligible directories remain, unless `recursive_max_depth` explicitly limits recursion.
5. Run deeper SecLists directory/file passes on high-signal hosts such as APIs, admin/dev/stage systems, non-CDN origins, unusual ports, and technology-specific targets.
6. Continue through the planned SecLists tiers; do not stop just because an early list found interesting paths.
7. Deduplicate normalized URLs while preserving the full evidence and parent/child path relationships for every result.

Always apply the global thread/delay/rate rules.

### Gobuster — directory brute force

```bash
DIR_WORDLIST="$SECLISTS/Discovery/Web-Content/raft-small-directories.txt"

gobuster dir -u "$URL" -w "$DIR_WORDLIST" \
  -t "${THREADS:-2}" --delay "${DELAY_MS:-30}ms" -l \
  -o "raw/gobuster_dirs_${SAFE_NAME}.txt"
```

For standard/deep passes, progress to `raft-medium-directories.txt`, `combined_directories.txt`, and/or `raft-large-directories.txt` according to host priority.

### Gobuster — filename brute force

```bash
FILE_WORDLIST="$SECLISTS/Discovery/Web-Content/raft-small-files.txt"

gobuster dir -u "$URL" -w "$FILE_WORDLIST" \
  -t "${THREADS:-2}" --delay "${DELAY_MS:-30}ms" -l \
  -o "raw/gobuster_files_${SAFE_NAME}.txt"
```

For standard/deep passes, progress to `raft-medium-files.txt` and `raft-large-files.txt`.

Add extensions only when technology/context supports them. Prefer extensions inferred from observed application technology, historical URLs, JavaScript references, server headers, and existing filenames.

### FFUF alternative with SecLists

Directory pass:

```bash
ffuf -w "$SECLISTS/Discovery/Web-Content/raft-medium-directories.txt" \
  -u "$URL/FUZZ" -ac -t "${THREADS:-2}" \
  -of json -o "raw/ffuf_dirs_${SAFE_NAME}.json"
```

File pass:

```bash
ffuf -w "$SECLISTS/Discovery/Web-Content/raft-medium-files.txt" \
  -u "$URL/FUZZ" -ac -t "${THREADS:-2}" \
  -of json -o "raw/ffuf_files_${SAFE_NAME}.json"
```

Apply the configured global delay/rate rules using the tool's supported controls. If `max_rps` is set, use it as an additional rate ceiling. A stricter program/target limit always wins.

### Required reporting fields

For every interesting directory/file result, preserve at least:

```text
url
host
path
type
status_code
content_length
content_type
redirect_location
title
tool
wordlist
wordlist_tier
parent_url
depth
discovered_from
timestamp_utc
notes
```

The final Markdown report must state the exact SecLists wordlists used for each host or host group and include discovered URLs with status codes, not only aggregate counts.

Never use this phase for password/credential guessing.

---


## Phase 11 — Low-impact Nuclei recon checks

For full/deep recon, attempt this phase whenever the user/program permits automated scanners. If automated scanners are prohibited, mark the phase `BLOCKED` with the exact policy reason rather than silently skipping it. Keep the default focused on detection, exposure, technology, and misconfiguration checks rather than DAST fuzzing or exploit-style behavior.

Rules:

- Update templates before a planned run if appropriate.
- Use JSONL output.
- Apply a conservative global rate limit.
- Respect required identification headers.
- Do not enable DAST/fuzz mode by default.
- Do not use OAST/interactsh unless the program explicitly permits it and the user asked for such checks.
- Treat scanner matches as leads requiring validation, not confirmed bugs.

Example conservative structure:

```bash
nuclei -l tables/live_urls.txt \
  -severity info,low,medium,high,critical \
  -rl 5 -jsonl -o raw/nuclei.jsonl
```

Before executing, inspect selected templates/tags so the run matches the program rules.

---

# Iterative wide-recon pivots

Repeat recon in controlled passes. Do not stop after the first successful pass. Continue until the inventory converges and no meaningful new authorized assets, services, URLs, certificate pivots, or content leads are produced.

Important flows from the supplied notes:

```text
subdomain enumeration -> DNS resolution -> CDN classification -> direct/non-CDN IPs
subdomain enumeration -> DNSx -> IPs -> HTTPX
root domain -> historical web data -> candidate origin IPs
CIDR -> port scan -> TLS certificate search -> domains + subdomains
CIDR -> HTTPS/TLS -> certificate SAN/CN -> domains + subdomains
CIDR -> port scan -> service discovery -> recon findings
CIDR -> PTR records -> candidate subdomains
subdomain enumeration -> DNSx -> CDN classification -> HTTP/TLS -> certificate pivots
```

Add these modern feedback loops:

```text
HTTP body/CSP/redirects -> hostnames -> scope check -> DNS
Katana/JS -> endpoints + hostnames -> scope check -> HTTP
TLS SANs -> scope check -> subdomain inventory
favicon hashes -> passive internet-search matches -> ownership evidence -> scope check
ports -> HTTP services on nonstandard ports -> crawl/content discovery
historical URLs -> parameter/path corpus -> targeted live validation
```

Always preserve provenance so a newly discovered asset can be traced back to the pivot that produced it.

---

# Data normalization

After every major phase, normalize raw output to canonical tables.

Use:

```bash
python3 scripts/normalize_outputs.py --workspace .
```

The helper script searches standardized raw filenames and produces/merges CSV tables in `tables/`.

Do not delete raw files after normalization.

Deduplication keys:

- roots: lowercase root domain
- subdomains: lowercase FQDN
- DNS: `(host, record_type, value)`
- HTTP: normalized `(scheme, host, port, path)`
- ports: `(ip_or_host, protocol, port)`
- TLS: `(ip_or_host, port, certificate_fingerprint)` when available
- URLs: normalized URL with fragment removed

Never collapse two assets just because they share an IP.

---

# Final reporting

Every completed run should produce:

```text
report/recon.md
report/all_in_scope_hosts.txt
report/live_urls.txt
report/open_ports.txt
report/interesting_urls.txt
```

## Markdown report requirements

Build the final report with:

```bash
python3 scripts/build_markdown.py --workspace . --output report/recon.md --max-rows 0
```

The Markdown report should contain, when data exists:

1. Executive Summary
2. Phase Completion
3. Scope
4. Root Domains / Company Properties
5. Candidate Assets Awaiting Scope Confirmation
6. Subdomains
7. DNS
8. HTTP Services
9. Open Ports / Services
10. TLS Certificates
11. Interesting URLs
12. URL Inventory
13. Content Discovery
14. Recon Findings
15. Sources, Commands, and Errors
16. Coverage Notes

Formatting rules:

- Use clear Markdown headings and detailed tables.
- By default, include the complete normalized dataset in the Markdown report (`--max-rows 0`); do not cap tables unless the user explicitly asks for a shorter report.
- Put summary counts near the top.
- Keep candidate assets visibly separate from confirmed in-scope assets.
- Preserve source/provenance columns so every pivot is explainable.
- Keep tool errors and unavailable phases visible.
- Use `—` for empty table values rather than malformed cells.
- Escape pipe/newline characters so tables remain readable.
- For very large datasets, show a readable capped table in Markdown and point to the full normalized CSV under `tables/`.
- Never hide excluded or low-signal assets when they explain why a pivot stopped.

The final `report/recon.md` is expected to be **full and detailed**, not a high-level summary. It must include:

- confirmed scope used and passive related-property inventory;
- counts of roots, subdomains, resolved/live hosts, unique IPs, open ports, TLS certs, URLs, content-discovery records, and recon findings;
- for every HTTP service when available: full URL, host, scheme, port, HTTP status code, title, technology, server header, content type, content length, redirect/location, IP, CNAME, CDN, ASN, favicon hash, response time, and discovery source;
- for every URL when available: full URL, host, path, query string, extension, HTTP status code, method, interesting/triage flag, and source;
- for every open service: host, IP, port, protocol, service, version, and source;
- for every TLS record: host/IP/port, subject CN/org, SANs, issuer, serial, validity, self-signed/expired/mismatch flags, fingerprint, and source;
- detailed DNS records, content-discovery hits, redirect targets, response sizes, and provenance;
- candidate assets awaiting scope confirmation;
- useful attack-surface observations supported by collected evidence;
- commands/tools that failed or were unavailable;
- program restrictions that affected coverage;
- next recon steps, if any.

Do not overstate scanner output as confirmed vulnerability findings.

---

# Tool behavior rules for Claude Code

1. Before using a CLI for the first time in a session, run `tool -h` or `tool --help` if flag compatibility is uncertain. Tools change over time.
2. Check `command -v TOOL` before relying on it.
3. Do not auto-install missing tools unless the user asked you to install dependencies. Instead, list what is missing and continue with alternatives.
4. Prefer JSON/JSONL/CSV native output over parsing colored terminal text.
5. Apply the user-configurable global execution rules to every compatible tool; defaults are 2 threads and at least 30ms delay unless a stricter target/program limit applies.
6. If a tool returns many wildcard/soft-404 results, pause that phase and calibrate filters rather than generating noise.
7. Broad passive discovery may include related non-scope/candidate assets, but never pipe unconfirmed assets into active probing tools.
8. Store errors; do not silently skip them.
9. Keep a reproducible command log without secrets.
10. Do not finish early: every applicable phase must be attempted and assigned a completion state.
11. At the end, run the normalizer and Markdown report builder with `--max-rows 0`, then verify `report/recon.md` exists, is non-empty, and includes detailed HTTP/URL/port/TLS data where collected.

---

# Completion checklist

A recon task is complete only when **all applicable phases have been attempted to completion** and:

- scope/exclusions are documented;
- candidates are separated from confirmed assets;
- multiple subdomain sources were merged where available;
- DNS resolution and wildcard handling were performed for active modes;
- live HTTP services were enriched;
- non-CDN/direct infrastructure was considered without deleting CDN hosts;
- port/service recon matched the permitted mode;
- TLS and historical/crawl pivots were processed;
- targeted content discovery was used selectively, not blindly;
- raw evidence and command provenance were retained;
- normalized tables were deduplicated;
- the Markdown report and supporting text outputs were generated;
- failures and coverage limitations are stated plainly;
- each phase has a visible completion state (`COMPLETED`, `COMPLETED_WITH_FALLBACK`, `NO_DATA`, or `BLOCKED`);
- iterative passes have converged;
- the Markdown report contains the full detailed inventories rather than only summary counts.
