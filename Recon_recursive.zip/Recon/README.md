# Bug Bounty Recon Skill for Claude Code

> **Wordlist rule:** directory and filename brute forcing uses the SecLists `Discovery/Web-Content/` repository by default, with separate directory/file passes and progressive RAFT wordlists.

Install either per project:

```bash
mkdir -p .claude/skills
cp -R bug-bounty-recon .claude/skills/bug-bounty-recon
```

or for your user account:

```bash
mkdir -p ~/.claude/skills
cp -R bug-bounty-recon ~/.claude/skills/bug-bounty-recon
```

Then ask Claude Code naturally, for example:

```text
Use the bug-bounty-recon skill. The program scope is in scope.txt. Run full recon.
Complete every applicable phase, keep wide passive related-property discovery enabled,
preserve raw evidence, and build the full detailed Markdown report.
```

The skill performs broad passive peripheral discovery across related properties, acquisitions, certificate names, shared infrastructure, ASN/CIDR relationships, and historical assets. This can reveal pivots back into authorized targets. Active probing remains gated by confirmed authorization.

## Helpers

```bash
scripts/init_workspace.sh PROGRAM_SLUG
python3 scripts/normalize_outputs.py --workspace recon/PROGRAM_SLUG
python3 scripts/build_markdown.py --workspace recon/PROGRAM_SLUG --output report/recon.md --max-rows 0
```

The Markdown report builder uses only the Python standard library.

## Default execution rules

The editable `execution_rules` block in `SKILL.md` starts with:

```yaml
threads: 2
delay_ms: 30
timeout_seconds: 15
retries: 1
max_rps: null
```

Full/deep recon must attempt every applicable phase and continue iterative pivots until the authorized inventory converges or a real blocker is recorded.


## Recursive content discovery

Every newly discovered directory is treated as a new brute-force root. The skill runs both directory and filename SecLists passes recursively until no new directories remain, unless `recursive_max_depth` is explicitly configured.
