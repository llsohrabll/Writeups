# Recon Reference

This file supports `SKILL.md`. It is intentionally more detailed so the main skill can stay readable.

## 1. Recommended tool set

### Core

- `subfinder` — passive subdomain enumeration
- `dnsx` — DNS resolution and record enrichment
- `httpx` — HTTP service probing/enrichment
- `naabu` — fast port discovery
- `nmap` — targeted service/version validation
- `tlsx` — TLS/certificate collection
- `katana` — crawler / JavaScript endpoint discovery
- `gobuster` — vhost and directory discovery
- `ffuf` — targeted content/vhost fuzzing
- `nuclei` — optional low-impact recon checks when program policy permits
- `mapcidr` — CIDR/IP matching, filtering, aggregation

### Useful companions

- `puredns` or `shuffledns` + `massdns` — DNS brute force and wildcard handling
- `waybackurls` — Wayback URL collection
- `gau` — historical URL aggregation
- `jq` — JSONL inspection
- `curl`, `dig`, `openssl` — spot checks and public data retrieval
- SecLists / custom curated wordlists

## 2. Installation examples

Do not auto-run these unless the user asks for dependency installation.

```bash
# ProjectDiscovery tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Other Go tools
go install github.com/OJ/gobuster/v3@latest
go install github.com/ffuf/ffuf/v2@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/d3mondev/puredns/v2@latest
go install -v github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest

# Markdown report helper uses only the Python standard library
```

Always check the upstream repository for changed module paths/requirements.

## 3. Standard raw filenames

Using predictable names makes `scripts/normalize_outputs.py` work with minimal configuration.

```text
raw/subfinder*.jsonl
raw/crtsh*.json
raw/puredns*.txt
raw/shuffledns*.txt
raw/dnsx*.jsonl
raw/httpx*.jsonl
raw/naabu*.jsonl
raw/tlsx*.jsonl
raw/katana*.jsonl
raw/waybackurls*.txt
raw/gau*.txt
raw/gobuster_vhost*.txt
raw/gobuster_dir*.txt
raw/ffuf*.json
raw/nuclei*.jsonl
```

## 4. Canonical tables

### `scope.csv`

```text
asset,asset_type,scope_status,source,evidence,notes
```

### `root_domains.csv`

```text
root_domain,relation,evidence_url,evidence_summary,scope_status,first_seen
```

### `subdomains.csv`

```text
root_domain,subdomain,resolved,ips,cname,source,first_seen,scope_status,wildcard,cdn,asn
```

### `dns.csv`

```text
host,record_type,value,status_code,resolver,cdn,asn,source
```

### `http.csv`

```text
url,host,scheme,port,status_code,title,tech,server,content_type,content_length,location,ip,cname,cdn,asn,favicon,response_time,source
```

### `ports.csv`

```text
host,ip,port,protocol,service,version,source
```

### `tls.csv`

```text
host,ip,port,subject_cn,subject_org,san,issuer,serial,not_before,not_after,self_signed,expired,mismatched,fingerprint_sha256,source
```

### `urls.csv`

```text
url,host,path,query,extension,source,status_code,method,interesting
```

### `content.csv`

```text
base_url,discovered_url,path,status_code,content_length,redirect,tool,source_file
```

### `findings.csv`

```text
type,severity,asset,evidence,source,status,notes
```

### `sources_errors.csv`

```text
timestamp,kind,phase,tool,target,command_or_error,source_file
```

## 5. Root-domain discovery notes integrated from the supplied recon notes

The supplied notes emphasize “wide recon” through company-property discovery before subdomain enumeration. Preserve these ideas:

- acquisitions and subsidiaries can reveal separate root domains;
- reverse WHOIS/domain-property services can connect assets;
- certificate searches can expose organization names and new DNS names;
- public hunter writeups can reveal recurring infrastructure naming patterns;
- search engines can locate acquisitions and copyright-string reuse;
- when ownership/scope is unclear, contact the security team rather than assuming.

This skill deliberately records these as `CANDIDATE` until the program confirms them.

## 6. Certificate-search interpretation

Interesting certificate fields include:

- `Issuer`
- `Subject`
- `Subject Organization`
- `Subject CN`
- `Subject Alternative Name`

A self-signed certificate can be interesting on a confirmed in-scope service, but it is not automatically a vulnerability.

A SAN matching a different root domain is a pivot lead, not permission to scan that domain.

## 7. Origin/CDN reasoning

The supplied notes recommend separating CDN-fronted infrastructure from direct IPs. Use that as prioritization rather than deletion.

Good questions:

- Does DNSx/HTTPX identify a CDN/WAF?
- Is an IP inside the CDN provider's published range?
- Does historical DNS show a different address?
- Does a direct in-scope hostname resolve outside the CDN?
- Does the certificate/HTTP behavior match the expected property?

Weak evidence that should not be treated as proof of origin:

- one old DNS record;
- matching server banner only;
- matching favicon only;
- “not in Cloudflare ranges” alone;
- shared cloud provider IP ownership.

## 8. Service discovery strategy

For many targets, use a focused port list or top 100 first.

For small, explicitly included address space, a broader scan can be justified if the program permits it.

Use Nmap for accuracy and version confirmation after Naabu finds ports.

The supplied notes specifically highlight:

```text
80,8000,8080,8880,2052,2082,2086,2095,443,2053,2083,2087,2096,8443,10443
```

Keep this as a useful web-oriented preset, not a universal truth.

## 9. Content discovery prioritization

### SecLists requirement for directory/file brute forcing

Use SecLists `Discovery/Web-Content/` as the default wordlist source for directory and filename brute forcing. Keep the directory and file passes separate and record the exact wordlist used.

Suggested progression:

```text
Directories:
  common.txt / raft-small-directories.txt
  -> raft-medium-directories.txt / combined_directories.txt
  -> raft-large-directories.txt for prioritized deep targets

Files:
  raft-small-files.txt
  -> raft-medium-files.txt
  -> raft-large-files.txt for prioritized deep targets
```

Auto-detect SecLists from `$SECLISTS_PATH`, `/usr/share/seclists`, `/usr/share/SecLists`, `/opt/SecLists`, or `./SecLists`.


Prioritize:

- API hosts
- admin/management names
- development/staging names
- nonstandard HTTP ports
- direct/non-CDN hosts
- hosts with unusual or custom software
- paths suggested by JavaScript, robots.txt, sitemap.xml, OpenAPI, or historical URLs

Avoid brute-forcing every host with huge lists. It creates noise and can violate rate limits.

## 10. Suggested interesting-URL heuristics

Mark as `interesting=true` if a URL/path contains terms such as:

```text
api
admin
internal
debug
swagger
openapi
graphql
grqphql
actuator
metrics
health
config
backup
old
staging
stage
dev
test
upload
export
import
callback
redirect
webhook
```

This is triage only; do not label a URL vulnerable based on its name.

Also prioritize URLs with:

- query parameters;
- file extensions associated with configs/backups/logs;
- nonstandard ports;
- historical-only paths that still respond;
- JavaScript-discovered API endpoints.

## 11. Reporting quality rules

The Markdown report is an attack-surface inventory. It should help a human decide what to inspect next.

Use these Markdown conventions:

- clear section headings;
- detailed tables with readable columns;
- default to uncapped Markdown tables so the final report contains the complete normalized inventory;
- explicit `IN_SCOPE`, `CANDIDATE`, `OUT_OF_SCOPE`, and `UNKNOWN` labels;
- separate candidate assets from confirmed in-scope assets;
- keep provenance/source fields visible;
- keep scanner matches marked unverified until manually validated;
- only cap a rendered table if the user explicitly requests a shorter report; otherwise use `--max-rows 0`.

Never use formatting to hide excluded or related assets. Keep passive relationship evidence visible, especially when it explains how a pivot led back to an authorized target.

## 12. Resume behavior

If the workspace already exists:

1. Read scope first.
2. Read command log and existing raw files.
3. Check which phases are already complete and which are missing/stale.
4. For a full/deep recon request, ensure every applicable phase reaches a completion state; rerun only what is missing, stale, failed transiently, or fed by new pivots.
5. Normalize again and rebuild the report.
6. If a previous asset changed from candidate to in-scope, move it through the active pipeline then.
7. Continue iterative passes until no meaningful new authorized assets/services/URLs/pivots are produced.

## 13. User-rule translation guidance

The editable `execution_rules` block in `SKILL.md` is the single source of truth for user-defined operational defaults. The initial example is `threads: 2` and `delay_ms: 30`.

For each active tool:

1. inspect the installed version's help when flag names/units are uncertain;
2. map `threads` to the tool's threads/workers/concurrency/parallelism control;
3. map `delay_ms` to a request/scan delay when supported;
4. if only RPS/rate controls exist, select a conservative setting that does not defeat the intended low concurrency/delay behavior;
5. never invent a flag or assume two tools use the same unit;
6. program/platform limits override user defaults when stricter;
7. write any unavoidable mapping exception into the run log.

Common semantic examples (flag spelling may change by version):

```text
Gobuster: worker threads + per-request delay
FFUF: worker threads + request delay/pacing
Nmap: max parallelism + scan delay
HTTP/DNS/crawler tools: concurrency plus delay or rate limit
Port scanners: concurrency/rate cap; avoid compensating for low threads with a high rate
```

The goal is consistent traffic behavior across the workflow, not blindly attaching unsupported flags to every command.

## 14. Full-run completion states

Every phase in a full/deep run must be recorded as one of:

- `COMPLETED`
- `COMPLETED_WITH_FALLBACK`
- `NO_DATA`
- `BLOCKED`

Do not silently skip phases. An interesting early discovery is not a reason to stop. Continue the workflow, feed discoveries forward, retry transient failures, use alternatives where practical, normalize again after important pivots, and finish only after the authorized inventory converges or a hard blocker is documented.

## 15. Detailed-report minimum fields

The final Markdown report should preserve full detail where collected. At minimum:

```text
HTTP: URL, host, scheme, port, status, title, tech, server, content type, content length, redirect/location, IP, CNAME, CDN, ASN, favicon, response time, source
URL: URL, host, path, query, extension, status, method, interesting flag, source
Port: host, IP, port, protocol, service, version, source
TLS: host, IP, port, subject CN/org, SANs, issuer, serial, validity, self-signed, expired, mismatch, fingerprint, source
DNS: host, record type, value, DNS status, resolver, CDN, ASN, source
Content: base URL, discovered URL/path, status, length, redirect, tool, source file
```

Use `scripts/build_markdown.py --max-rows 0` for the default full report.


## Recursive directory discovery

Content discovery is recursive by default.

Whenever a directory is found:

```text
target/
  -> target/newdir/
      -> run directory brute force
      -> run file brute force
      -> enqueue every newly discovered child directory
```

Continue until there are no unvisited discovered directories left, unless `recursive_max_depth` is explicitly configured.

Track:

```text
URL
parent URL
depth
status
content length
redirect
tool
wordlist
discovery source
processed state
```

Deduplicate normalized paths and guard against redirect loops, equivalent-path loops, calendar traps, numeric expansion traps, and session/cache-busting URL variants.
