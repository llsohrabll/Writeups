#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <domain-or-url>" >&2
  exit 2
fi

TARGET_INPUT="$1"

TARGET_HOST="$(
python3 - "$TARGET_INPUT" <<'PY'
import sys
from urllib.parse import urlsplit

raw = sys.argv[1].strip()
candidate = raw if "://" in raw else "https://" + raw
u = urlsplit(candidate)
host = (u.hostname or "").rstrip(".").lower()
if not host:
    raise SystemExit("Invalid target")
print(host)
PY
)"

SAFE_TARGET="$(printf '%s' "$TARGET_HOST" | tr -c 'A-Za-z0-9._-' '_')"
ROOT="wide-recon-${SAFE_TARGET}"

mkdir -p "$ROOT"/{00_target,01_subdomains,02_dns,03_http,04_ports,05_tls,06_vhosts,07_history,08_crawl,09_content,10_nuclei,raw,tables,logs,state,report}

printf '%s\n' "$TARGET_HOST" > "$ROOT/00_target/target.txt"
{
  printf '%s\n' "$TARGET_HOST"
  printf '*.%s\n' "$TARGET_HOST"
} > "$ROOT/00_target/allowed_hosts_rule.txt"

cat > "$ROOT/state/phases.tsv" <<'EOF'
phase	status	started_utc	finished_utc	tool	fallback	notes
0_target	PENDING					
1_subdomains	PENDING					
2_dns	PENDING					
3_http	PENDING					
4_ports	PENDING					
5_tls	PENDING					
6_vhosts	PENDING					
7_history	PENDING					
8_crawl	PENDING					
9_content	PENDING					
10_nuclei	PENDING					
11_iteration	PENDING					
12_report	PENDING					
EOF

echo "Workspace: $ROOT"
echo "Target:    $TARGET_HOST"
