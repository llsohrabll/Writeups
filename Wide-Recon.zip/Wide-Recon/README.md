# Wide-Recon

Claude Code reconnaissance skill invoked as:

```text
/Wide-Recon test.com
```

The supplied hostname is the only root boundary.

For `test.com`, Wide-Recon may enumerate and recon:

```text
test.com
*.test.com
all paths on those hosts
all discovered web services on those hosts
```

It does not pivot into unrelated root domains.

## Install per project

Copy the `Wide-Recon` folder to:

```text
.claude/skills/Wide-Recon/
```

The important file will be:

```text
.claude/skills/Wide-Recon/SKILL.md
```

## Install globally

Copy the folder to:

```text
~/.claude/skills/Wide-Recon/
```

## Run

```text
/Wide-Recon test.com
```

## Key defaults

```yaml
threads: 2
delay_ms: 30
all_phases_required: true
recursive_content_discovery: true
recursive_max_depth: null
seclists_required_for_content_discovery: true
report_format: markdown
report_detail: full
```

The final report is:

```text
report/Wide-Recon.md
```
