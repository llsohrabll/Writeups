---
name: Wide-Recon
description: Exhaustive single-target reconnaissance skill for an explicitly supplied bug-bounty/pentest target. Invoke as /Wide-Recon <domain-or-url>. The supplied hostname is the only root boundary; enumerate and recon that hostname, its subdomains, services, URLs, and recursive web content, but never pivot into unrelated root domains. Run every applicable phase to completion and produce a full Markdown report.
---

# Wide-Recon

## Invocation

Use exactly one target argument:

```text
/Wide-Recon test.com
```

Other valid examples:

```text
/Wide-Recon https://test.com
/Wide-Recon api.test.com
/Wide-Recon https://api.test.com:8443
```

The text after `/Wide-Recon` is the **only target input**.

Do not require a separate scope file before starting.

---

# 1. CRITICAL TARGET-BOUNDARY RULE

Normalize the supplied argument first.

Example:

```text
input:       https://test.com/login?x=1
target_host: test.com
```

If the user supplies:

```text
/Wide-Recon test.com
```

the allowed hostname boundary is:

```text
test.com
*.test.com
```

If the user supplies:

```text
/Wide-Recon api.test.com
```

the allowed hostname boundary is:

```text
api.test.com
*.api.test.com
```

Do **not** automatically widen `api.test.com` to the parent `test.com`.

Define the hostname matcher conceptually as:

```text
ALLOWED(host):
    host == TARGET_HOST
    OR
    host ends with "." + TARGET_HOST
```

This matcher applies to every hostname discovered from:

- Subfinder
- certificate transparency
- DNS brute force
- HTTP responses
- redirects
- CSP
- HTML/DOM
- JavaScript
- historical URLs
- TLS SAN/CN values
- virtual-host discovery
- crawling
- content discovery
- DNS PTR/CNAME clues
- any other recon source

A discovered hostname outside this matcher is an **external reference**.

For external references:

```text
record the reference if useful
do not enqueue it
do not enumerate its subdomains
do not port-scan it
do not crawl it
do not brute-force it
do not run Nuclei against it
do not pivot the recon root into it
```

This skill is therefore **wide inside one supplied hostname tree**, not wide across unrelated company properties.

Do not perform:

```text
acquisition-domain expansion
subsidiary root-domain expansion
reverse-WHOIS root-domain expansion
organization-wide ASN/CIDR expansion
unrelated certificate-domain expansion
favicon pivots into unrelated root domains
```

The target argument always wins.

---

# 2. CRITICAL FULL-RUN COMPLETION RULE

A Wide-Recon run is not complete after finding a few subdomains or live hosts.

**Every applicable phase must be run patiently and carried through to completion.**

Rules:

1. Run all phases in this skill.
2. Do not stop because an interesting endpoint, admin panel, API, service, or possible vulnerability is found.
3. Feed every valid discovery into all later applicable phases.
4. Retry transient failures according to the configured retry count.
5. If a preferred tool is unavailable, use a compatible fallback and record it.
6. Never silently skip a phase.
7. Re-run affected downstream phases when a late discovery creates new hosts, ports, URLs, or directories.
8. Continue iterative recon until the target inventory converges.
9. "Converged" means no meaningful new allowed hostnames, services, URLs, directories, files, or recon pivots are being produced.
10. Every phase must finish with one of:

```text
COMPLETED
COMPLETED_WITH_FALLBACK
NO_DATA
BLOCKED
```

`BLOCKED` requires a concrete reason such as a missing dependency that cannot be installed, inaccessible network service, or an explicit user/environment restriction.

Do not mark the run complete while actionable recon work remains queued.

---

# 3. USER-CONFIGURABLE GLOBAL RULES

Edit this block to change global behavior:

```yaml
execution_rules:
  all_phases_required: true
  threads: 2
  delay_ms: 30
  timeout_seconds: 15
  retries: 1
  max_rps: null

  enumerate_subdomains: true
  recursive_content_discovery: true
  recursive_max_depth: null

  seclists_required_for_content_discovery: true
  seclists_path: auto

  report_format: markdown
  report_detail: full
  report_row_limit: null

  extra_rules: []
```

Interpretation:

- `threads: 2`
  - use two threads/workers/concurrent requests where the tool exposes a compatible control.
- `delay_ms: 30`
  - use at least a 30 ms delay between requests/work units where a tool supports delay/pacing.
- `timeout_seconds: 15`
  - use a 15-second compatible timeout.
- `retries: 1`
  - retry transient failures once.
- `max_rps`
  - if set, treat it as an additional requests-per-second ceiling.
- `recursive_content_discovery: true`
  - every new directory becomes a new directory + file brute-force root.
- `recursive_max_depth: null`
  - continue recursively until no new directories remain.
- `report_row_limit: null`
  - do not truncate detailed report tables.
- `extra_rules`
  - user-editable global instructions that apply to the entire run.

Do not invent unsupported CLI flags. Translate these rules into each tool's actual controls.

Examples:

```text
Gobuster: -t 2 and --delay 30ms
FFUF:     -t 2 and compatible pacing/delay controls
HTTPX:   set compatible concurrency/rate controls
Katana:  set compatible concurrency/rate controls
Naabu:   use conservative compatible rate controls
Nmap:    do not fake a thread flag; use supported timing controls only
```

If a tool cannot express an exact 30 ms delay, use the nearest safer supported pacing control and document the translation.

---

# 4. REQUIRED OUTPUT WORKSPACE

Create a workspace named from the normalized target:

```text
wide-recon-<target>/
├── 00_target/
├── 01_subdomains/
├── 02_dns/
├── 03_http/
├── 04_ports/
├── 05_tls/
├── 06_vhosts/
├── 07_history/
├── 08_crawl/
├── 09_content/
├── 10_nuclei/
├── raw/
├── tables/
├── logs/
├── state/
└── report/
```

Write the normalized target to:

```text
00_target/target.txt
```

Also create:

```text
00_target/allowed_hosts_rule.txt
```

containing the exact matching rule:

```text
TARGET_HOST
*.TARGET_HOST
```

Maintain phase state in:

```text
state/phases.tsv
```

Recommended columns:

```text
phase	status	started_utc	finished_utc	tool	fallback	notes
```

---

# 5. PHASE 0 — TARGET NORMALIZATION

Parse the single argument.

Normalization requirements:

- lowercase hostname;
- remove URL credentials;
- remove query and fragment for target-root purposes;
- preserve an explicitly supplied port as an initial service hint;
- convert IDN safely when needed;
- remove one trailing dot from DNS names;
- reject empty/invalid hostnames.

Examples:

```text
test.com
https://test.com/
https://test.com:8443/login
```

become a target definition similar to:

```text
TARGET_HOST=test.com
TARGET_SCHEME=https      # only if explicitly supplied
TARGET_PORT=8443         # only if explicitly supplied
```

Do not derive another root domain from ownership information.

---

# 6. PHASE 1 — PASSIVE SUBDOMAIN DISCOVERY

Goal:

```text
TARGET_HOST -> as many valid TARGET_HOST descendants as possible
```

Use multiple passive sources.

## Subfinder

Preferred:

```bash
subfinder -d "$TARGET_HOST" -all -oJ -cs -o raw/subfinder.jsonl
```

Extract and deduplicate hostnames.

Only keep:

```text
TARGET_HOST
*.TARGET_HOST
```

## Certificate Transparency

Query CT sources such as crt.sh and other configured passive providers.

For every SAN/CN hostname:

1. lowercase;
2. remove leading `*.`;
3. normalize trailing dot;
4. apply `ALLOWED(host)`;
5. deduplicate.

## Other passive sources when available

Examples:

```text
Chaos
Censys
Shodan host metadata
GitHub/source-code search
Sourcegraph
passive DNS/history
public certificate datasets
AbuseIPDB hostname context
search-engine indexed hostnames
```

These sources are used only to discover names inside the supplied target tree.

Do not pivot into a different root domain.

Write:

```text
01_subdomains/passive.txt
tables/subdomains.csv
```

Recommended fields:

```text
hostname
source
first_seen_utc
resolved
live_http
notes
```

---

# 7. PHASE 2 — ACTIVE DNS DISCOVERY + RESOLUTION

## DNS brute force

Use SecLists DNS wordlists when available:

```text
SecLists/Discovery/DNS/
```

Start with an appropriate smaller/high-signal list, then progress when full recon is requested.

Resolve candidates as:

```text
WORD.TARGET_HOST
```

Do not brute-force an unrelated suffix.

Tools may include:

```text
dnsx
puredns
shuffledns
massdns
```

Use wildcard-aware resolution.

## DNSx

Resolve all discovered allowed hostnames.

Collect at least:

```text
hostname
A
AAAA
CNAME
MX
NS
TXT when useful
resolver
response_code
```

Example concept:

```bash
dnsx -l 01_subdomains/all.txt -a -aaaa -cname -resp -json \
  -o raw/dnsx.jsonl
```

Use trustworthy resolvers.

Where appropriate, include the target's authoritative nameservers as additional resolution context.

Write:

```text
02_dns/resolved_hosts.txt
02_dns/dns_records.jsonl
tables/dns.csv
```

## Dynamic permutation pass

After passive enumeration:

1. extract observed tokens such as:
   - dev
   - stage
   - staging
   - prod
   - api
   - admin
   - internal
   - region names
   - service names;
2. generate sensible permutations;
3. resolve them;
4. keep only names inside the target hostname tree.

Feed every new valid hostname back into DNS resolution.

---

# 8. PHASE 3 — HTTP SERVICE DISCOVERY WITH HTTPX

HTTPX is the primary HTTP/HTTPS service detector.

Probe every resolved allowed hostname and useful discovered port.

Collect as much structured metadata as supported:

```text
url
scheme
host
port
status_code
title
webserver
technology
content_type
content_length
redirect_location
ip
cname
asn
cdn
favicon_hash
response_time
tls
method
source
timestamp_utc
```

Preferred JSONL output.

Example concept:

```bash
httpx -l 02_dns/resolved_hosts.txt \
  -status-code -title -tech-detect -server \
  -content-type -content-length -location \
  -ip -cname -asn -cdn -favicon -response-time \
  -json -o raw/httpx.jsonl
```

Apply compatible thread/rate/timeout rules.

### Redirect rule

Record every redirect.

Follow a redirect for recon only if its destination hostname passes `ALLOWED(host)`.

If it redirects to another root domain:

```text
record destination as external_reference
do not enqueue it
```

Write:

```text
03_http/live_urls.txt
tables/http.csv
```

---

# 9. PHASE 4 — PORT + SERVICE DISCOVERY

Do not perform organization-wide ASN/CIDR expansion.

Port discovery is tied only to the supplied target tree and IPs directly resolved from allowed target hostnames.

## CDN handling

Identify whether an IP appears to be CDN/shared edge infrastructure.

Record CDN information.

Do not treat a shared CDN range as permission to expand into the full range.

## Naabu

For large hostname inventories, begin with useful/top ports.

Include common alternate web ports such as:

```text
80
443
8000
8080
8081
8088
8880
8443
9443
10443
3000
3001
5000
5001
7001
9000
9090
2052
2053
2082
2083
2086
2087
2095
2096
```

For small, clearly target-associated non-CDN origin sets, a broader port pass may be used when requested by the full recon policy.

Save structured output.

## Nmap validation

Validate interesting/open ports with Nmap.

Useful service-detection controls include:

```text
-sV
-sT
-Pn
-n
```

Use only flags appropriate to the situation.

Collect:

```text
host
ip
port
protocol
state
service
product
version
banner/details
source
```

Every newly discovered HTTP-like service must be sent back into HTTPX and later web phases.

Write:

```text
04_ports/open_ports.txt
tables/ports.csv
```

---

# 10. PHASE 5 — TLS / CERTIFICATE MINING

Use tools such as:

```text
tlsx
openssl
nmap TLS scripts where appropriate
```

Collect:

```text
host
ip
port
subject
issuer
CN
SANs
organization
not_before
not_after
serial
fingerprint
self_signed
tls_version
cipher context when useful
```

For every SAN/CN:

```text
if ALLOWED(name):
    enqueue into subdomain/DNS pipeline
else:
    record only as external reference
```

Never turn an unrelated SAN root into a new recon target.

Write:

```text
05_tls/certificates.jsonl
tables/tls.csv
```

---

# 11. PHASE 6 — VIRTUAL-HOST DISCOVERY

Perform vhost discovery only in the supplied hostname tree.

Candidate vhost names must resolve conceptually to:

```text
WORD.TARGET_HOST
```

or be derived allowed descendants.

Tools:

```text
ffuf
gobuster vhost
```

Use SecLists DNS/vhost-oriented lists where useful.

Example concept:

```bash
ffuf -w "$WORDLIST" \
  -u "https://$TARGET_HOST/" \
  -H "Host: FUZZ.$TARGET_HOST" \
  -ac -t 2
```

Validate every result by:

```text
response difference
DNS when applicable
HTTPX
TLS/certificate evidence
```

Feed valid new hostnames into the subdomain/DNS/HTTP pipeline.

Write:

```text
06_vhosts/vhosts.txt
tables/vhosts.csv
```

---

# 12. PHASE 7 — HISTORICAL URL DISCOVERY

Use tools/sources such as:

```text
waybackurls
gau
Common Crawl
Internet Archive
public URL datasets
```

Seed only with the target hostname tree.

For every historical URL:

1. parse hostname;
2. keep it for active follow-up only if `ALLOWED(host)`;
3. normalize URL;
4. preserve query parameter names;
5. deduplicate.

Collect useful historical patterns:

```text
API paths
admin paths
login/auth paths
backup/config filenames
old extensions
JavaScript files
API versioning
parameterized URLs
upload/download endpoints
debug endpoints
old environments
```

Write:

```text
07_history/urls.txt
tables/history_urls.csv
```

---

# 13. PHASE 8 — CRAWLING + JAVASCRIPT DISCOVERY

Use Katana as the primary crawler where available.

Seed it with every live allowed URL.

Collect:

```text
URL
method
source URL
status when available
content type
JavaScript URLs
forms
parameters
API endpoints
linked allowed hostnames
robots.txt
sitemap.xml
```

Example concept:

```bash
katana -list 03_http/live_urls.txt \
  -jc -kf all -jsonl \
  -o raw/katana.jsonl
```

Apply compatible concurrency/rate rules.

From HTML, JavaScript, headers, CSP, and DOM:

- extract allowed hostnames;
- extract relative and absolute endpoints;
- extract API base paths;
- extract parameter names;
- extract referenced files;
- extract websocket endpoints when visible.

Any new allowed hostname:

```text
-> DNS
-> HTTPX
-> ports when applicable
-> TLS
-> crawling
-> content discovery
```

Write:

```text
08_crawl/urls.txt
08_crawl/javascript.txt
tables/crawl.csv
```

---

# 14. PHASE 9 — CONTENT DISCOVERY WITH SECLISTS

## IMPORTANT — SECLISTS IS REQUIRED BY DEFAULT

For directory and filename brute forcing, use:

```text
SecLists/Discovery/Web-Content/
```

when:

```yaml
seclists_required_for_content_discovery: true
```

Auto-detect:

```bash
if [ -n "${SECLISTS_PATH:-}" ] && [ -d "$SECLISTS_PATH" ]; then
  SECLISTS="$SECLISTS_PATH"
elif [ -d /usr/share/seclists ]; then
  SECLISTS=/usr/share/seclists
elif [ -d /usr/share/SecLists ]; then
  SECLISTS=/usr/share/SecLists
elif [ -d /opt/SecLists ]; then
  SECLISTS=/opt/SecLists
elif [ -d ./SecLists ]; then
  SECLISTS=./SecLists
else
  SECLISTS=""
fi
```

If SecLists is required and missing:

- record the dependency issue;
- install/clone it when the environment permits;
- otherwise mark the content-discovery phase `BLOCKED`;
- do not silently pretend another wordlist was SecLists.

## Directory lists

Recommended progression:

```text
common.txt
raft-small-directories.txt
raft-medium-directories.txt
combined_directories.txt
raft-large-directories.txt
```

## File lists

Recommended progression:

```text
raft-small-files.txt
raft-medium-files.txt
raft-large-files.txt
```

Use technology-specific lists when observed fingerprints support them, such as:

```text
API
GraphQL
IIS
Apache
Java/J2EE
CMS/framework
backup/configuration files
Swagger/OpenAPI
```

Keep directory and filename discovery as separate passes.

---

# 15. CRITICAL RECURSIVE DIRECTORY RULE

Whenever a new directory is discovered, **always recursively recon that directory**.

Required model:

```text
https://test.com/
    -> directory brute force
    -> file brute force

found:
https://test.com/test1/

mandatory next:
https://test.com/test1/
    -> directory brute force
    -> file brute force

found:
https://test.com/test1/admin/

mandatory next:
https://test.com/test1/admin/
    -> directory brute force
    -> file brute force
```

This applies to every live allowed HTTP service, including alternate ports:

```text
https://test.com/
https://test.com:8443/
https://api.test.com/
```

## Queue algorithm

Conceptually:

```text
queue = all live base URLs
visited = set()

while queue is not empty:
    current = queue.pop()

    canonical_current = normalize(current)

    if canonical_current in visited:
        continue

    run directory brute force on current
    run file brute force on current

    visited.add(canonical_current)

    for each discovered directory:
        if hostname is ALLOWED
           and directory is not visited
           and depth <= configured limit:
               queue.push(directory)
```

With:

```yaml
recursive_max_depth: null
```

there is no artificial directory-depth cutoff.

Continue until:

```text
queue is empty
AND
no new eligible directory was discovered
```

Do not stop recursion just because an interesting endpoint was found.

## Recursion loop protection

Canonicalize and guard against:

```text
redirect loops
duplicate slash forms
dot segments
URL-encoding aliases
self-referential paths
calendar/date traps
unbounded numeric sequences
session IDs
cache-busting parameters
repeated pagination traps
case-only duplicates where appropriate
```

## Required recursive-content metadata

For every result preserve:

```text
url
host
port
path
type
parent_url
depth
status_code
content_length
content_type
redirect_location
title
tool
wordlist
wordlist_tier
discovered_from
first_seen_utc
processed
notes
```

---

# 16. GOBUSTER / FFUF CONTENT-DISCOVERY EXAMPLES

## Gobuster directory pass

```bash
gobuster dir \
  -u "$BASE_URL" \
  -w "$SECLISTS/Discovery/Web-Content/raft-small-directories.txt" \
  -t 2 \
  --delay 30ms \
  -l \
  -o "raw/gobuster_dirs_${SAFE_NAME}.txt"
```

## Gobuster file pass

```bash
gobuster dir \
  -u "$BASE_URL" \
  -w "$SECLISTS/Discovery/Web-Content/raft-small-files.txt" \
  -t 2 \
  --delay 30ms \
  -l \
  -o "raw/gobuster_files_${SAFE_NAME}.txt"
```

## FFUF directory pass

```bash
ffuf \
  -w "$SECLISTS/Discovery/Web-Content/raft-medium-directories.txt" \
  -u "$BASE_URL/FUZZ" \
  -ac \
  -t 2 \
  -of json \
  -o "raw/ffuf_dirs_${SAFE_NAME}.json"
```

## FFUF file pass

```bash
ffuf \
  -w "$SECLISTS/Discovery/Web-Content/raft-medium-files.txt" \
  -u "$BASE_URL/FUZZ" \
  -ac \
  -t 2 \
  -of json \
  -o "raw/ffuf_files_${SAFE_NAME}.json"
```

Apply the configured delay/rate using each tool's supported controls.

Do not brute-force credentials/passwords in this phase.

---

# 17. PHASE 10 — LOW-IMPACT NUCLEI RECON

After the inventory is mature, Nuclei may be used for low-impact reconnaissance and exposed/misconfiguration checks on allowed target URLs.

Feed only URLs whose hostname passes `ALLOWED(host)`.

Prefer categories that do not require destructive behavior.

Preserve:

```text
template_id
template_name
severity
matched_at
host
type
extracts
timestamp
```

Do not stop the overall Wide-Recon workflow because Nuclei finds something.

Write:

```text
10_nuclei/findings.jsonl
tables/nuclei.csv
```

---

# 18. ITERATIVE RECON LOOP

After all initial phases, perform another pivot pass.

Required loops include:

```text
Subfinder/CT -> DNS -> HTTPX
HTTPX -> redirects/CNAME/TLS -> allowed hostname candidates -> DNS
ports -> HTTP-like service -> HTTPX -> crawl -> content discovery
TLS SAN/CN -> allowed hostnames -> DNS -> HTTPX
historical URLs -> allowed hosts/paths -> live validation
Katana/JS/CSP -> allowed hosts/paths -> validation
new directory -> recursive directory + file brute force
new subdomain -> all applicable host phases
new web port -> all applicable web phases
```

Continue until convergence.

A late `api.test.com` discovery is not just appended to a file.

It must receive the applicable pipeline:

```text
DNS
HTTPX
ports
TLS
history
crawl
recursive content discovery
Nuclei recon
reporting
```

---

# 19. DATA NORMALIZATION RULES

Normalize continuously.

## Hostnames

```text
lowercase
remove trailing dot
remove leading "*."
IDN canonicalization where relevant
```

## URLs

Preserve:

```text
scheme
hostname
port
path
query parameter names
```

Avoid destroying useful distinct paths.

## Deduplication

Deduplicate by the correct key:

```text
hostname
hostname + record type + value
URL
host + port
certificate fingerprint
content URL + discovery source where provenance matters
```

Never discard provenance just because two tools found the same asset.

---

# 20. REQUIRED FINAL MARKDOWN REPORT

The final output is:

```text
report/Wide-Recon.md
```

It must be **full, detailed, readable, and uncapped by default**.

Do not provide only a short summary.

The report must contain:

## 20.1 Target

```text
Original input
Normalized target host
Allowed hostname rule
Run start/end UTC
Global execution rules
```

## 20.2 Executive summary

Counts such as:

```text
subdomains discovered
DNS-resolving hosts
live HTTP services
unique URLs
open ports
TLS certificates
historical URLs
crawled URLs
directories discovered
files discovered
Nuclei recon findings
external references ignored from further recon
```

## 20.3 Phase completion

Table:

```text
Phase | Status | Tool(s) | Fallback | Notes
```

Every phase must appear.

## 20.4 Subdomains

Full table:

```text
Hostname | Resolved | Live HTTP | Sources | Notes
```

## 20.5 DNS

Full table:

```text
Hostname | Type | Value | Resolver | Source
```

## 20.6 HTTP services

For every service include, where available:

```text
URL
Host
Scheme
Port
Status Code
Title
Technology
Web Server
Content Type
Content Length
Redirect Location
IP
CNAME
ASN
CDN
Favicon Hash
Response Time
TLS
Discovery Source
```

Do not collapse this into only counts.

## 20.7 Ports and services

```text
Host
IP
Port
Protocol
State
Service
Product
Version
Banner/Details
Source
```

## 20.8 TLS

```text
Host
Port
Subject
Issuer
CN
SANs
Organization
Validity
Fingerprint
Self-signed
TLS details
```

## 20.9 Virtual hosts

```text
Vhost
Base host/IP
Status
Title
Length
Validation evidence
Source
```

## 20.10 Historical URLs

List full normalized URLs, status/live-validation when available, and source.

## 20.11 Crawled URLs

Include:

```text
URL
Status
Content Type
Source URL
Method
Parameters
Technology/context
```

## 20.12 Recursive content discovery

This section is mandatory and detailed.

Include:

```text
URL
Parent URL
Depth
Type
Status Code
Content Length
Content Type
Title
Redirect
Tool
SecLists Wordlist
Wordlist Tier
Discovered From
```

Also list every SecLists wordlist actually used.

## 20.13 Interesting recon observations

Evidence-backed observations only.

Examples:

```text
admin/development interfaces
unusual web ports
old API versions
backup/config-looking files
debug paths
Swagger/OpenAPI endpoints
GraphQL endpoints
origin-looking hosts
interesting redirects
technology/version exposure
unusual TLS certificates
```

Do not omit raw evidence needed to verify each observation.

## 20.14 External references

If a response points to an unrelated root domain, record:

```text
external hostname/url
where it was observed
reason it was not queued
```

Do not recon it.

## 20.15 Errors / fallbacks

Include:

```text
phase
tool
command purpose
error
retry
fallback
final state
```

---

# 21. REPORT QUALITY RULES

The report must:

- be valid Markdown;
- use readable headings;
- use tables for structured data;
- use code blocks for commands/log snippets;
- preserve complete URLs;
- include status codes;
- include source/provenance;
- avoid duplicate rows;
- avoid hiding data behind vague summaries;
- avoid arbitrary 100/500-row truncation;
- state clearly when a field was unavailable;
- state every phase's completion status;
- include raw output file paths for evidence.

If a table becomes too wide, split it into logically related tables rather than dropping fields.

---

# 22. EXPECTED RUN BEHAVIOR

When invoked:

```text
/Wide-Recon test.com
```

Claude should interpret the task as:

```text
Perform an exhaustive Wide-Recon against test.com.

The only hostname tree is:
  test.com
  *.test.com

Run every recon phase.
Use the global 2-thread / 30ms defaults.
Enumerate subdomains.
Resolve DNS.
Probe HTTP.
Discover ports/services.
Mine TLS certificates.
Enumerate target-tree virtual hosts.
Collect historical URLs.
Crawl live applications and JavaScript.
Use SecLists for directory and file brute forcing.
Recursively brute force every newly discovered directory.
Run low-impact recon checks.
Repeat pivots until convergence.
Generate a complete detailed Markdown report.
Do not pivot into unrelated root domains.
```

---

# 23. DEFINITION OF DONE

Wide-Recon is complete only when all of the following are true:

- the supplied argument was normalized;
- the target-host boundary was enforced;
- passive subdomain discovery completed;
- active DNS discovery/resolution completed;
- HTTP service discovery completed;
- port/service discovery completed;
- TLS mining completed;
- vhost discovery completed;
- historical URL collection completed;
- crawling/JavaScript discovery completed;
- SecLists directory discovery completed;
- SecLists file discovery completed;
- every discovered directory was recursively processed;
- Nuclei recon phase completed or was explicitly blocked;
- every late allowed hostname/service was fed through applicable downstream phases;
- all phase states were recorded;
- the iterative queue converged;
- raw evidence was preserved;
- `report/Wide-Recon.md` was produced;
- the report contains full URL/status/service/content details.

Do not announce completion before these conditions are satisfied.
