# Wide-Recon Reference

## Single-target model

`/Wide-Recon <target>` uses the supplied hostname as the only root.

Examples:

```text
/Wide-Recon test.com
  allowed: test.com, api.test.com, dev.api.test.com
  external: test.net, vendor.com

/Wide-Recon api.test.com
  allowed: api.test.com, dev.api.test.com
  external: test.com, www.test.com
```

Do not perform acquisition, reverse-WHOIS, subsidiary-root, organization-wide ASN/CIDR, or unrelated certificate-root expansion.

## Core toolchain

Preferred tools include:

```text
subfinder
dnsx
puredns / shuffledns
httpx
naabu
nmap
tlsx / openssl
gobuster
ffuf
waybackurls
gau
katana
nuclei
```

Use compatible alternatives when tools are unavailable and record fallback use.

## SecLists

Default web-content root:

```text
SecLists/Discovery/Web-Content/
```

Useful directory progression:

```text
common.txt
raft-small-directories.txt
raft-medium-directories.txt
combined_directories.txt
raft-large-directories.txt
```

Useful file progression:

```text
raft-small-files.txt
raft-medium-files.txt
raft-large-files.txt
```

Use technology-specific lists when evidence supports them.

## Recursive content discovery

Every new directory is another base URL:

```text
/
-> /api/
   -> /api/v1/
      -> /api/v1/admin/
```

Each base gets:

```text
directory brute force
file brute force
```

Continue until the queue is empty unless `recursive_max_depth` is configured.

## Reporting

The final Markdown report should preserve full evidence, especially:

```text
URL
status code
title
technology
server
content type
content length
redirect
IP
CNAME
CDN
ASN
response time
port/service/version
TLS certificate metadata
directory/file parent + recursion depth
SecLists wordlist
source/provenance
```
